package com.flashbackinventory.render;

import com.flashbackinventory.FlashbackInventory;
import com.flashbackinventory.config.FlashbackInventoryConfig;
import com.flashbackinventory.record.DeathSnapshot;
import com.flashbackinventory.record.KeySnapshot;
import com.flashbackinventory.record.MenuSnapshot;
import com.flashbackinventory.record.ScreenSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.Flashback;
import com.moulberry.flashback.playback.ReplayServer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * Redraws the recorded GUI in the centre of the screen while spectating a player's
 * first-person view during a Flashback replay and that player has a menu open.
 * <p>
 * Uses a clean translucent style: the world is dimmed in the background, the panel and every
 * slot (including empty ones) are drawn as translucent wells, and the player's mouse trail and
 * the item held by the cursor during recording are also shown.
 */
public final class ReplayInventoryOverlay implements HudElement {

    public static final Identifier ID = FlashbackInventory.id("replay_inventory_overlay");

    /** Toggleable via the mod keybind. */
    public static volatile boolean enabled = true;

    /** Shared condition used by the overlay and the crosshair-hiding mixin. */
    public static boolean isGuiVisible() {
        if (!enabled || !FlashbackInventoryConfig.renderEnabled || !Flashback.isInReplay()) {
            return false;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return false;
        }
        if (!minecraft.options.getCameraType().isFirstPerson()) {
            return false;
        }
        if (!(minecraft.getCameraEntity() instanceof Player player)) {
            return false;
        }
        ReplayServer server = Flashback.getReplayServer();
        if (server == null) {
            return false;
        }
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        if (menu != null && menu.open()) {
            return true;
        }
        ScreenSnapshot scr = ReplayInventoryStore.getScreen(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        return scr != null && scr.open();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        Minecraft minecraft = Minecraft.getInstance();
        // Held-key display + death filter: whenever replaying from a player's view
        // (independent of GUI visibility).
        if (Flashback.isInReplay() && minecraft.level != null
                && minecraft.getCameraEntity() instanceof Player cameraPlayer) {
            ReplayServer server = Flashback.getReplayServer();
            if (server != null) {
                drawDeathFilter(extractor, minecraft, cameraPlayer, server);
                // Held keys fade out over a configurable number of ticks after release.
                int tick = server.getReplayTick();
                int fade = Math.max(1, FlashbackInventoryConfig.keyFadeTicks);
                int lastHeld = ReplayInventoryStore.lastHeldKeysTick(
                        cameraPlayer.getUUID(), minecraft.level.dimension(), tick, fade);
                if (lastHeld >= 0) {
                    KeySnapshot ks = ReplayInventoryStore.getKeys(
                            cameraPlayer.getUUID(), minecraft.level.dimension(), lastHeld);
                    if (ks != null && !ks.keys().isEmpty()) {
                        int diff = tick - lastHeld;
                        int alpha = 255;
                        if (diff > 0 && fade > 0) {
                            alpha = Math.max(0, 255 * (fade - diff) / fade);
                        }
                        drawKeys(extractor, minecraft, ks, alpha);
                    }
                }
            }
        }
        if (!isGuiVisible()) {
            return;
        }
        Player player = (Player) minecraft.getCameraEntity();
        ReplayServer server = Flashback.getReplayServer();
        int tick = server.getReplayTick();
        ScreenSnapshot scr = ReplayInventoryStore.getScreen(
                player.getUUID(), minecraft.level.dimension(), tick);
        if (scr != null && scr.open()) {
            drawScreen(extractor, minecraft, scr);
            return;
        }
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), tick);
        if (menu == null) {
            return;
        }
        List<MenuSnapshot> recent = ReplayInventoryStore.getRecentMenus(
                player.getUUID(), minecraft.level.dimension(), tick,
                FlashbackInventoryConfig.recordMouseTrail ? FlashbackInventoryConfig.trailLength : 0);
        drawMenu(extractor, minecraft, menu, recent);
    }

    /** Full-screen red/black tint while the spectated player is dead, until they respawn. */
    private void drawDeathFilter(GuiGraphicsExtractor extractor, Minecraft minecraft,
                                 Player player, ReplayServer server) {
        DeathSnapshot dead = ReplayInventoryStore.getDeath(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        if (dead == null || !dead.dead()) {
            return;
        }
        int sw = minecraft.getWindow().getGuiScaledWidth();
        int sh = minecraft.getWindow().getGuiScaledHeight();
        int color = "red".equals(FlashbackInventoryConfig.deathColor)
                ? 0x66FF0000 : 0x77000000;
        extractor.fill(0, 0, sw, sh, color);
    }

    /** Draws the chat screen as a bottom input bar whose width fits exactly one line of text, left-aligned. */
    private void drawScreen(GuiGraphicsExtractor extractor, Minecraft minecraft, ScreenSnapshot snap) {
        String extra = snap.extraText() == null ? "" : snap.extraText();
        Font font = minecraft.font;
        int pad = 8;
        int w = Math.max(120, font.width(extra) + pad * 2 + 14);
        int sw = minecraft.getWindow().getGuiScaledWidth();
        int sh = minecraft.getWindow().getGuiScaledHeight();
        int x = 4; // left-aligned, like the vanilla chat input bar
        int y = sh - 22;
        // Translucent world background while a screen is open.
        int bgAlpha = FlashbackInventoryConfig.backgroundAlpha & 0xFF;
        extractor.fill(0, 0, sw, sh, (bgAlpha << 24));
        int pAlpha = FlashbackInventoryConfig.guiPanelAlpha & 0xFF;
        extractor.fill(x, y, x + w, y + 18, (pAlpha << 24));
        extractor.text(font, ">", x + 4, y + 5, 0xFFFFFF);
        extractor.text(font, extra, x + 14, y + 5, 0xFFFFFFFF);
    }

    /** Draws held keys as chips in the bottom-right corner, at the given opacity (0..255, for fade-out). */
    private void drawKeys(GuiGraphicsExtractor extractor, Minecraft minecraft, KeySnapshot ks, int alpha) {
        Font font = minecraft.font;
        int sw = minecraft.getWindow().getGuiScaledWidth();
        int sh = minecraft.getWindow().getGuiScaledHeight();
        int a = alpha & 0xFF;
        int totalW = 0;
        for (String k : ks.keys()) {
            totalW += font.width(k) + 10;
        }
        int x = sw - totalW - 8;
        int y = sh - 22;
        int fillColor = (a << 24);
        int textColor = 0xFFFFFF | (a << 24);
        for (String k : ks.keys()) {
            int w = font.width(k) + 10;
            extractor.fill(x, y, x + w, y + 16, fillColor);
            extractor.text(font, k, x + 5, y + 4, textColor);
            x += w;
        }
    }

    private void drawMenu(GuiGraphicsExtractor extractor, Minecraft minecraft,
                          MenuSnapshot menu, List<MenuSnapshot> recent) {
        int width = menu.width();
        int height = menu.height();
        int x = (minecraft.getWindow().getGuiScaledWidth() - width) / 2;
        int y = (minecraft.getWindow().getGuiScaledHeight() - height) / 2;

        // Translucent world background (opacity configurable).
        int bgAlpha = FlashbackInventoryConfig.backgroundAlpha & 0xFF;
        extractor.fill(0, 0, minecraft.getWindow().getGuiScaledWidth(),
                minecraft.getWindow().getGuiScaledHeight(), (bgAlpha << 24));
        // Lighter panel background (opacity configurable).
        int pAlpha = FlashbackInventoryConfig.guiPanelAlpha & 0xFF;
        extractor.fill(x, y, x + width, y + height, (pAlpha << 24));

        // Slot wells for ALL slots (empty slots render as wells too) + items.
        Font font = minecraft.font;
        int wellAlpha = (int) (pAlpha * 1.5f) & 0xFF;
        for (MenuSnapshot.MenuSlotData s : menu.slots()) {
            int sx = x + s.x();
            int sy = y + s.y();
            extractor.fill(sx, sy, sx + 16, sy + 16, (wellAlpha << 24));
            ItemStack stack = s.stack();
            if (!stack.isEmpty()) {
                extractor.item(stack, sx + 1, sy + 1);
                extractor.itemDecorations(font, stack, sx + 1, sy + 1);
            }
        }

        // Menu title.
        if (menu.title() != null && !menu.title().isEmpty()) {
            extractor.text(font, menu.title(), x + 8, y + 6, 0xFFFFFFFF);
        }

        // Mouse trail: recent recorded cursor positions (normalized centre-relative -> screen).
        float sw = minecraft.getWindow().getGuiScaledWidth();
        float sh = minecraft.getWindow().getGuiScaledHeight();
        if (FlashbackInventoryConfig.recordMouseTrail) {
            for (MenuSnapshot m : recent) {
                int rx = (int) (sw / 2.0f + m.mouseX() * sw);
                int ry = (int) (sh / 2.0f + m.mouseY() * sh);
                extractor.fill(rx, ry, rx + 3, ry + 3, 0x80FFFFFF);
            }
        }
        // Current cursor marker.
        int mx = (int) (sw / 2.0f + menu.mouseX() * sw);
        int my = (int) (sh / 2.0f + menu.mouseY() * sh);
        if (FlashbackInventoryConfig.recordMouseTrail) {
            extractor.fill(mx - 2, my - 2, mx + 2, my + 2, 0xFFFFFFFF);
        }
        // Item held by the cursor.
        ItemStack carried = menu.carried();
        if (carried != null && !carried.isEmpty()) {
            extractor.item(carried, mx - 8, my - 8);
        }
    }
}
