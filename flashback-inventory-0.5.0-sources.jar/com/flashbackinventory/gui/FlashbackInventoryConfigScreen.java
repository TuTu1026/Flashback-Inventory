package com.flashbackinventory.gui;

import com.flashbackinventory.config.FlashbackInventoryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Configuration screen opened from Mod Menu. Single-column, scrollable layout. Numeric settings
 * can be edited as text input or a slider (toggled with a "/" button, precision 1). GUI depth has
 * a live colour preview. Supports English / 中文.
 */
public final class FlashbackInventoryConfigScreen extends Screen {

    private static final Map<String, String> ZH_NAMES = new HashMap<>();

    static {
        ZH_NAMES.put("inventory", "物品栏");
        ZH_NAMES.put("chest", "箱子");
        ZH_NAMES.put("crafting_table", "工作台");
        ZH_NAMES.put("furnace", "熔炉");
        ZH_NAMES.put("smoker", "烟熏炉");
        ZH_NAMES.put("blast_furnace", "高炉");
        ZH_NAMES.put("brewing_stand", "酿造台");
        ZH_NAMES.put("enchanting_table", "附魔台");
        ZH_NAMES.put("anvil", "铁砧");
        ZH_NAMES.put("beacon", "信标");
        ZH_NAMES.put("grindstone", "磨石");
        ZH_NAMES.put("cartography_table", "制图台");
        ZH_NAMES.put("loom", "织布机");
        ZH_NAMES.put("smithing", "锻造台");
        ZH_NAMES.put("stonecutter", "切石机");
        ZH_NAMES.put("dispenser", "发射器");
        ZH_NAMES.put("hopper", "漏斗");
        ZH_NAMES.put("shulker_box", "潜影盒");
        ZH_NAMES.put("horse", "马");
        ZH_NAMES.put("villager", "村民");
        ZH_NAMES.put("crafter", "合成器");
    }

    private final Screen parent;
    private ColorPreview alphaPreview;

    /** Scroll offset (<= 0). Kept static so rebuilds (language/mode switches) keep the position. */
    private static int scrollY = 0;
    private int contentHeight = 0;

    public FlashbackInventoryConfigScreen(Screen parent) {
        super(Component.literal(t("Flashback Inventory Settings", "Flashback 背包设置")));
        this.parent = parent;
    }

    @Override
    protected void init() {
        final int row = 20;

        // Clamp scroll based on the previous layout's height.
        int maxScroll = Math.max(0, contentHeight + 24 - (this.height - 34));
        scrollY = Math.max(-maxScroll, Math.min(0, scrollY));
        int y = 8 + scrollY;

        // 1) Done - first option.
        Button done = Button.builder(Component.literal(t("Done", "完成")), b -> this.onClose())
                .bounds(10, y, 300, 20).build();
        this.addRenderableWidget(done);
        y += row;

        // 2) Language toggle.
        Button langBtn = Button.builder(Component.literal(t("Language: English", "语言：中文")), b -> {
            FlashbackInventoryConfig.language = FlashbackInventoryConfig.language.equals("zh") ? "en" : "zh";
            FlashbackInventoryConfig.save();
            Minecraft.getInstance().gui.setScreen(new FlashbackInventoryConfigScreen(parent));
        }).bounds(10, y, 300, 18).build();
        this.addRenderableWidget(langBtn);
        y += row;

        // 2) Master render toggle.
        addToggle(10, y, 300, () -> FlashbackInventoryConfig.renderEnabled,
                v -> FlashbackInventoryConfig.renderEnabled = v,
                t("Render replay GUI", "回放渲染GUI"));
        y += row;

        // 3) Mouse-trail recording toggle.
        addToggle(10, y, 300, () -> FlashbackInventoryConfig.recordMouseTrail,
                v -> FlashbackInventoryConfig.recordMouseTrail = v,
                t("Record mouse trail", "录制鼠标轨迹"));
        y += row;

        // 3.5) Record chat toggle.
        addToggle(10, y, 300, () -> FlashbackInventoryConfig.recordChat,
                v -> FlashbackInventoryConfig.recordChat = v,
                t("Record chat", "录制聊天"));
        y += row;

        // 4) Trail tail length.
        numericRow(y, "trailLength", t("Trail tail length", "轨迹尾巴长度"), 10, 60,
                v -> FlashbackInventoryConfig.trailLength = v);
        y += row;

        // 5) Container scan radius.
        numericRow(y, "containerScanRadius", t("Container scan radius", "容器扫描半径"), 4, 64,
                v -> FlashbackInventoryConfig.containerScanRadius = v);
        y += row;

        // 6) GUI depth with live colour preview.
        numericRow(y, "guiPanelAlpha", t("GUI depth", "GUI深浅"), 0, 255,
                v -> FlashbackInventoryConfig.guiPanelAlpha = v);
        y += row;

        // 7) Select all / none (one row).
        Button allBtn = Button.builder(Component.literal(t("Select all", "全选")), b -> {
            for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
                FlashbackInventoryConfig.containerEnabled.put(key, true);
            }
            FlashbackInventoryConfig.save();
            rebuildButtons();
        }).bounds(10, y, 145, 18).build();
        this.addRenderableWidget(allBtn);
        Button noneBtn = Button.builder(Component.literal(t("Select none", "全不选")), b -> {
            for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
                FlashbackInventoryConfig.containerEnabled.put(key, false);
            }
            FlashbackInventoryConfig.save();
            rebuildButtons();
        }).bounds(160, y, 150, 18).build();
        this.addRenderableWidget(noneBtn);
        y += row;

        // 8) Per-container toggles, single column (scrollable).
        for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
            String k = key;
            Button cb = Button.builder(Component.literal(containerLabel(k)), b -> {
                boolean v = FlashbackInventoryConfig.containerEnabled.getOrDefault(k, true);
                FlashbackInventoryConfig.containerEnabled.put(k, !v);
                FlashbackInventoryConfig.save();
                b.setMessage(Component.literal(containerLabel(k)));
            }).bounds(10, y, 300, 16).build();
            this.addRenderableWidget(cb);
            y += 18;
        }
        contentHeight = y;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        int maxScroll = Math.max(0, contentHeight + 24 - (this.height - 34));
        int newY = (int) Math.round(scrollY - vertical * 18);
        newY = Math.max(-maxScroll, Math.min(0, newY));
        if (newY != scrollY) {
            scrollY = newY;
            rebuildButtons();
        }
        return true;
    }

    /** A full-width ON/OFF toggle button in the single column. */
    private void addToggle(int x, int y, int w, java.util.function.BooleanSupplier get,
                           Consumer<Boolean> set, String base) {
        Button b = Button.builder(Component.literal(base + ": " + onoff(get.getAsBoolean())), btn -> {
            set.accept(!get.getAsBoolean());
            FlashbackInventoryConfig.save();
            btn.setMessage(Component.literal(base + ": " + onoff(get.getAsBoolean())));
        }).bounds(x, y, w, 18).build();
        this.addRenderableWidget(b);
    }

    /** A numeric row: label button (shows value) + "/" mode toggle + EditBox or Slider. */
    private void numericRow(int y, String key, String label, int min, int max, Consumer<Integer> setter) {
        Button labelBtn = Button.builder(Component.literal(label + " = " + valueOf(key)), b -> {
        }).bounds(10, y, 150, 18).build();
        labelBtn.active = false;
        this.addRenderableWidget(labelBtn);

        Runnable refresh = () -> {
            labelBtn.setMessage(Component.literal(label + " = " + valueOf(key)));
            if (alphaPreview != null) {
                alphaPreview.color = (FlashbackInventoryConfig.guiPanelAlpha << 24);
            }
            FlashbackInventoryConfig.save();
        };

        if (key.equals("guiPanelAlpha")) {
            alphaPreview = new ColorPreview(162, y + 1, 14, 16, (FlashbackInventoryConfig.guiPanelAlpha << 24));
            this.addRenderableWidget(alphaPreview);
        }

        Button slash = Button.builder(Component.literal("/"), b -> {
            boolean newMode = !FlashbackInventoryConfig.editMode.getOrDefault(key, false);
            FlashbackInventoryConfig.editMode.put(key, newMode);
            Minecraft.getInstance().gui.setScreen(new FlashbackInventoryConfigScreen(parent));
        }).bounds(key.equals("guiPanelAlpha") ? 178 : 162, y, 18, 18).build();
        this.addRenderableWidget(slash);

        int editX = key.equals("guiPanelAlpha") ? 198 : 182;
        boolean sliderMode = FlashbackInventoryConfig.editMode.getOrDefault(key, false);
        if (sliderMode) {
            this.addRenderableWidget(new NumSlider(editX, y, 120, 18, min, max, valueOf(key),
                    v -> {
                        setter.accept(v);
                        refresh.run();
                    }));
        } else {
            EditBox eb = new EditBox(this.font, editX, y + 1, 120, 16, Component.literal(""));
            eb.setMaxLength(3);
            eb.setValue(String.valueOf(valueOf(key)));
            eb.setResponder(s -> {
                try {
                    int v = Integer.parseInt(s.trim());
                    v = Math.max(min, Math.min(max, v));
                    setter.accept(v);
                    refresh.run();
                } catch (NumberFormatException ignored) {
                    // keep typing until a valid number
                }
            });
            this.addRenderableWidget(eb);
        }
    }

    private static int valueOf(String key) {
        return switch (key) {
            case "trailLength" -> FlashbackInventoryConfig.trailLength;
            case "containerScanRadius" -> FlashbackInventoryConfig.containerScanRadius;
            case "guiPanelAlpha" -> FlashbackInventoryConfig.guiPanelAlpha;
            default -> 0;
        };
    }

    private void rebuildButtons() {
        Minecraft.getInstance().gui.setScreen(new FlashbackInventoryConfigScreen(parent));
    }

    private static String containerLabel(String key) {
        String name = FlashbackInventoryConfig.language.equals("zh")
                ? ZH_NAMES.getOrDefault(key, key)
                : key;
        return name + ":" + onoff(FlashbackInventoryConfig.containerEnabled.getOrDefault(key, true));
    }

    private static String onoff(boolean on) {
        return on ? (FlashbackInventoryConfig.language.equals("zh") ? "开" : "ON")
                : (FlashbackInventoryConfig.language.equals("zh") ? "关" : "OFF");
    }

    private static String t(String en, String zh) {
        return FlashbackInventoryConfig.language.equals("zh") ? zh : en;
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().gui.setScreen(parent);
    }

    /** Numeric slider, precision 1. */
    private static final class NumSlider extends AbstractSliderButton {
        private final int min;
        private final int max;
        private final Consumer<Integer> apply;

        NumSlider(int x, int y, int w, int h, int min, int max, int current, Consumer<Integer> apply) {
            super(x, y, w, h, Component.literal(""), (max > min) ? (current - min) / (double) (max - min) : 0.0);
            this.min = min;
            this.max = max;
            this.apply = apply;
            updateMessage();
        }

        private int current() {
            return (int) Math.round(min + this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(String.valueOf(current())));
        }

        @Override
        protected void applyValue() {
            apply.accept(current());
        }
    }

    /** Small solid colour swatch used as the GUI-depth preview. */
    private static final class ColorPreview extends AbstractWidget {
        private int color;

        ColorPreview(int x, int y, int w, int h, int color) {
            super(x, y, w, h, Component.empty());
            this.color = color;
        }

        @Override
        protected void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
            g.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), color);
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
        }
    }
}
