package com.flashbackinventory.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Persistent config (config/flashback-inventory.json) exposed through the Mod Menu screen.
 */
public final class FlashbackInventoryConfig {

    /** Container GUI keys that can be individually toggled for recording. */
    public static final List<String> CONTAINER_KEYS = List.of(
            "inventory", "chest", "crafting_table", "furnace", "smoker", "blast_furnace",
            "brewing_stand", "enchanting_table", "anvil", "beacon", "grindstone", "cartography_table",
            "loom", "smithing", "stonecutter", "dispenser", "hopper", "shulker_box", "horse", "villager", "crafter");

    /** Container scan radius in blocks. */
    public static int containerScanRadius = 24;
    /** Whether the replay overlay redraws interfaces at all. */
    public static boolean renderEnabled = true;
    /** Per-container-type recording toggle (key -> enabled). */
    public static final Map<String, Boolean> containerEnabled = new LinkedHashMap<>();
    /** Whether to record/redraw the mouse trail. */
    public static boolean recordMouseTrail = true;
    /** Length of the mouse trail tail (number of recorded frames shown). */
    public static int trailLength = 30;
    /** Settings-screen language: "en" or "zh". */
    public static String language = "en";
    /** GUI panel / slot background opacity (0..255). Higher = darker interface. */
    public static int guiPanelAlpha = 60;
    /** Whether chat input is recorded and replayed. */
    public static boolean recordChat = true;
    /** UI-only edit-mode per numeric key: true = slider, false = text input. Not persisted. */
    public static final Map<String, Boolean> editMode = new LinkedHashMap<>();

    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir().resolve("flashback-inventory.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private record Data(int containerScanRadius, boolean renderEnabled,
                        Map<String, Boolean> containerEnabled, boolean recordMouseTrail,
                        int trailLength, String language, int guiPanelAlpha, boolean recordChat) {
    }

    static {
        for (String key : CONTAINER_KEYS) {
            containerEnabled.put(key, true);
        }
        load();
    }

    private FlashbackInventoryConfig() {
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Data data = GSON.fromJson(Files.readString(FILE), Data.class);
                if (data != null) {
                    containerScanRadius = data.containerScanRadius();
                    renderEnabled = data.renderEnabled();
                    recordMouseTrail = data.recordMouseTrail();
                    trailLength = data.trailLength();
                    if (data.language() != null) {
                        language = data.language();
                    }
                    guiPanelAlpha = data.guiPanelAlpha();
                    recordChat = data.recordChat();
                    // Merge stored toggles with defaults so new container types keep their defaults.
                    if (data.containerEnabled() != null) {
                        for (Map.Entry<String, Boolean> e : data.containerEnabled().entrySet()) {
                            containerEnabled.put(e.getKey(), e.getValue());
                        }
                    }
                }
            }
        } catch (Exception ignored) {
            // Best-effort; defaults are used on any failure.
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(new Data(containerScanRadius, renderEnabled,
                    new LinkedHashMap<>(containerEnabled), recordMouseTrail, trailLength, language,
                    guiPanelAlpha, recordChat)));
        } catch (Exception ignored) {
            // Best-effort.
        }
    }
}
