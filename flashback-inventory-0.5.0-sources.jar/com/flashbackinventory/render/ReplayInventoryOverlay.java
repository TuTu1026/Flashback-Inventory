package com.flashbackinventory.render;

import com.flashbackinventory.FlashbackInventory;
import com.flashbackinventory.config.FlashbackInventoryConfig;
import com.flashbackinventory.record.KeySnapshot;
import com.flashbackinventory.record.MenuSnapshot;
import com.flashbackinventory.record.ScreenSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.Flashback;
import com.moulberry.flashback.playback.ReplayServer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * Redraws the recorded GUI in the centre of the screen while spectating a player's
 * first-person view during a Flashback replay and that player has a menu open.
 * <p>
 * Uses a clean translucent style: the world is dimmed in the background, the panel and every
 * slot (including empty ones) are drawn as translucent wells, and the player's mouse trail and
 * the item held by the cursor during recording are also shown.
 */
public final class ReplayInventoryOverlay implements HudElement {

    public static final Identifier ID = FlashbackInventory.id("replay_inventory_overlay");

    /** Toggleable via the mod keybind. */
    public static volatile boolean enabled = true;

    /** Shared condition used by the overlay and the crosshair-hiding mixin. */
    public static boolean isGuiVisible() {
        if (!enabled || !FlashbackInventoryConfig.renderEnabled || !Flashback.isInReplay()) {
            return false;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return false;
        }
        if (!minecraft.options.getCameraType().isFirstPerson()) {
            return false;
        }
        if (!(minecraft.getCameraEntity() instanceof Player player)) {
            return false;
        }
        ReplayServer server = Flashback.getReplayServer();
        if (server == null) {
            return false;
        }
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        if (menu != null && menu.open()) {
            return true;
        }
        ScreenSnapshot scr = ReplayInventoryStore.getScreen(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        return scr != null && scr.open();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        Minecraft minecraft = Minecraft.getInstance();
        // Held-key display: bottom-right, whenever replaying from a player's view (independent of GUI visibility).
        if (Flashback.isInReplay() && minecraft.level != null
                && minecraft.getCameraEntity() instanceof Player cameraPlayer) {
            ReplayServer server = Flashback.getReplayServer();
            if (server != null) {
                KeySnapshot ks = ReplayInventoryStore.getKeys(
                        cameraPlayer.getUUID(), minecraft.level.dimension(), server.getReplayTick());
                if (ks != null && !ks.keys().isEmpty()) {
                    drawKeys(extractor, minecraft, ks);
                }
            }
        }
        if (!isGuiVisible()) {
            return;
        }
        Player player = (Player) minecraft.getCameraEntity();
        ReplayServer server = Flashback.getReplayServer();
        int tick = server.getReplayTick();
        ScreenSnapshot scr = ReplayInventoryStore.getScreen(
                player.getUUID(), minecraft.level.dimension(), tick);
        if (scr != null && scr.open()) {
            drawScreen(extractor, minecraft, scr);
            return;
        }
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), tick);
        if (menu == null) {
            return;
        }
        List<MenuSnapshot> recent = ReplayInventoryStore.getRecentMenus(
                player.getUUID(), minecraft.level.dimension(), tick,
                FlashbackInventoryConfig.recordMouseTrail ? FlashbackInventoryConfig.trailLength : 0);
        drawMenu(extractor, minecraft, menu, recent);
    }

    /** Draws the chat screen as a bottom input bar whose width fits exactly one line of text. */
    private void drawScreen(GuiGraphicsExtractor extractor, Minecraft minecraft, ScreenSnapshot snap) {
        String extra = snap.extraText() == null ? "" : snap.extraText();
        Font font = minecraft.font;
        int pad = 8;
        int w = Math.max(120, font.width(extra) + pad * 2 + 14);
        int sw = minecraft.getWindow().getGuiScaledWidth();
        int sh = minecraft.getWindow().getGuiScaledHeight();
        int x = (sw - w) / 2;
        int y = sh - 22;
        int pAlpha = FlashbackInventoryConfig.guiPanelAlpha & 0xFF;
        extractor.fill(x, y, x + w, y + 18, (pAlpha << 24));
        extractor.text(font, ">", x + 4, y + 5, 0xFFFFFF);
        extractor.text(font, extra, x + 14, y + 5, 0xFFFFFFFF);
    }

    /** Draws held keys as chips in the bottom-right corner. */
    private void drawKeys(GuiGraphicsExtractor extractor, Minecraft minecraft, KeySnapshot ks) {
        Font font = minecraft.font;
        int sw = minecraft.getWindow().getGuiScaledWidth();
        int sh = minecraft.getWindow().getGuiScaledHeight();
        int totalW = 0;
        for (String k : ks.keys()) {
            totalW += font.width(k) + 10;
        }
        int x = sw - totalW - 8;
        int y = sh - 22;
        for (String k : ks.keys()) {
            int w = font.width(k) + 10;
            extractor.fill(x, y, x + w, y + 16, 0x90000000);
            extractor.text(font, k, x + 5, y + 4, 0xFFFFFFFF);
            x += w;
        }
    }

    private void drawMenu(GuiGraphicsExtractor extractor, Minecraft minecraft,
                          MenuSnapshot menu, List<MenuSnapshot> recent) {
        int width = menu.width();
        int height = menu.height();
        int x = (minecraft.getWindow().getGuiScaledWidth() - width) / 2;
        int y = (minecraft.getWindow().getGuiScaledHeight() - height) / 2;

        // Translucent world background.
        extractor.fill(0, 0, minecraft.getWindow().getGuiScaledWidth(),
                minecraft.getWindow().getGuiScaledHeight(), 0x55000000);
        // Lighter panel background (opacity configurable).
        int pAlpha = FlashbackInventoryConfig.guiPanelAlpha & 0xFF;
        extractor.fill(x, y, x + width, y + height, (pAlpha << 24));

        // Slot wells for ALL slots (empty slots render as wells too) + items.
        Font font = minecraft.font;
        int wellAlpha = (int) (pAlpha * 1.5f) & 0xFF;
        for (MenuSnapshot.MenuSlotData s : menu.slots()) {
            int sx = x + s.x();
            int sy = y + s.y();
            extractor.fill(sx, sy, sx + 16, sy + 16, (wellAlpha << 24));
            ItemStack stack = s.stack();
            if (!stack.isEmpty()) {
                extractor.item(stack, sx + 1, sy + 1);
                extractor.itemDecorations(font, stack, sx + 1, sy + 1);
            }
        }

        // Menu title.
        if (menu.title() != null && !menu.title().isEmpty()) {
            extractor.text(font, menu.title(), x + 8, y + 6, 0xFFFFFFFF);
        }

        // Mouse trail: recent recorded cursor positions (normalized centre-relative -> screen).
        float sw = minecraft.getWindow().getGuiScaledWidth();
        float sh = minecraft.getWindow().getGuiScaledHeight();
        if (FlashbackInventoryConfig.recordMouseTrail) {
            for (MenuSnapshot m : recent) {
                int rx = (int) (sw / 2.0f + m.mouseX() * sw);
                int ry = (int) (sh / 2.0f + m.mouseY() * sh);
                extractor.fill(rx, ry, rx + 3, ry + 3, 0x80FFFFFF);
            }
        }
        // Current cursor marker.
        int mx = (int) (sw / 2.0f + menu.mouseX() * sw);
        int my = (int) (sh / 2.0f + menu.mouseY() * sh);
        if (FlashbackInventoryConfig.recordMouseTrail) {
            extractor.fill(mx - 2, my - 2, mx + 2, my + 2, 0xFFFFFFFF);
        }
        // Item held by the cursor.
        ItemStack carried = menu.carried();
        if (carried != null && !carried.isEmpty()) {
            extractor.item(carried, mx - 8, my - 8);
        }
    }
}
