package com.flashbackinventory.render;

import com.flashbackinventory.FlashbackInventory;
import com.flashbackinventory.record.MenuSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.Flashback;
import com.moulberry.flashback.playback.ReplayServer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Redraws the recorded GUI in the centre of the screen, but only while:
 * <ul>
 *   <li>a Flashback replay is playing back, and</li>
 *   <li>the viewer is spectating a player's first-person view
 *       ({@code cameraEntity instanceof Player} and first-person camera), and</li>
 *   <li>that player had a container/inventory menu open at the current replay tick.</li>
 * </ul>
 */
public final class ReplayInventoryOverlay implements HudElement {

    public static final Identifier ID = FlashbackInventory.id("replay_inventory_overlay");

    /** Toggleable via the mod keybind. */
    public static volatile boolean enabled = true;

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        if (!enabled || !Flashback.isInReplay()) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return;
        }
        // Only when spectating a player in first-person.
        if (!minecraft.options.getCameraType().isFirstPerson()) {
            return;
        }
        if (!(minecraft.getCameraEntity() instanceof Player player)) {
            return;
        }

        ReplayServer server = Flashback.getReplayServer();
        if (server == null) {
            return;
        }
        int tick = server.getReplayTick();

        MenuSnapshot menu = ReplayInventoryStore.getMenu(player.getUUID(), minecraft.level.dimension(), tick);
        if (menu == null) {
            return;
        }

        drawMenu(extractor, minecraft, menu);
    }

    private void drawMenu(GuiGraphicsExtractor extractor, Minecraft minecraft, MenuSnapshot menu) {
        int width = menu.width();
        int height = menu.height();
        int x = (minecraft.getWindow().getGuiScaledWidth() - width) / 2;
        int y = (minecraft.getWindow().getGuiScaledHeight() - height) / 2;

        // Panel background (vanilla GUI texture, stretched to the recorded window size).
        extractor.blit(menu.textureId(), x, y, width, height, 0.0f, 0.0f, 1.0f, 1.0f);

        Font font = minecraft.font;
        for (MenuSnapshot.MenuSlotData s : menu.slots()) {
            int sx = x + s.x();
            int sy = y + s.y();
            ItemStack stack = s.stack();
            extractor.item(stack, sx + 1, sy + 1);
            extractor.itemDecorations(font, stack, sx + 1, sy + 1);
        }

        // Menu title drawn on the panel's title strip.
        extractor.text(font, menu.title(), x + 8, y + 6, 0xFF404040);
    }
}
