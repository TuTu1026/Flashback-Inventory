package com.flashbackinventory.store;

import com.flashbackinventory.record.InventorySnapshot;
import com.flashbackinventory.record.KeySnapshot;
import com.flashbackinventory.record.MenuSnapshot;
import com.flashbackinventory.record.ScreenSnapshot;
import com.flashbackinventory.record.DeathSnapshot;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Time-series registry of recorded snapshots.
 * <p>
 * Every snapshot is stored with the replay tick at which it was recorded/applied. During playback
 * the overlay asks for the snapshot whose recorded tick is the latest one not after the current
 * replay tick, so inventories/menus evolve through the replay instead of showing only the final state.
 */
public final class ReplayInventoryStore {

    private record Timed<T>(int tick, T value) {
    }

    private record PlayerKey(UUID uuid, ResourceKey<Level> dimension) {
    }

    private record ContainerKey(ResourceKey<Level> dimension, BlockPos pos) {
    }

    private record MenuKey(UUID uuid, ResourceKey<Level> dimension) {
    }

    private static final ConcurrentHashMap<PlayerKey, List<Timed<InventorySnapshot>>> PLAYER_INV =
            new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<ContainerKey, List<Timed<InventorySnapshot>>> CONTAINER_INV =
            new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<MenuKey, List<Timed<MenuSnapshot>>> MENUS =
            new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<MenuKey, List<Timed<ScreenSnapshot>>> SCREENS =
            new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<MenuKey, List<Timed<KeySnapshot>>> KEYS =
            new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<MenuKey, List<Timed<DeathSnapshot>>> DEATHS =
            new ConcurrentHashMap<>();

    private ReplayInventoryStore() {
    }

    public static void putPlayer(int tick, InventorySnapshot snap) {
        add(PLAYER_INV, new PlayerKey(snap.playerUuid(), snap.dimension()), new Timed<>(tick, snap));
    }

    public static void putContainer(int tick, InventorySnapshot snap) {
        add(CONTAINER_INV, new ContainerKey(snap.dimension(), snap.blockPos()), new Timed<>(tick, snap));
    }

    public static void putMenu(int tick, MenuSnapshot snap) {
        add(MENUS, new MenuKey(snap.playerUuid(), snap.dimension()), new Timed<>(tick, snap));
    }

    public static void putScreen(int tick, ScreenSnapshot snap) {
        add(SCREENS, new MenuKey(snap.playerUuid(), snap.dimension()), new Timed<>(tick, snap));
    }

    public static void putKeys(int tick, KeySnapshot snap) {
        add(KEYS, new MenuKey(snap.playerUuid(), snap.dimension()), new Timed<>(tick, snap));
    }

    public static void putDeath(int tick, DeathSnapshot snap) {
        add(DEATHS, new MenuKey(snap.playerUuid(), snap.dimension()), new Timed<>(tick, snap));
    }

    public static InventorySnapshot getPlayer(UUID uuid, ResourceKey<Level> dimension, int tick) {
        return latestAt(PLAYER_INV, new PlayerKey(uuid, dimension), tick);
    }

    public static InventorySnapshot getContainer(ResourceKey<Level> dimension, BlockPos pos, int tick) {
        return latestAt(CONTAINER_INV, new ContainerKey(dimension, pos), tick);
    }

    public static MenuSnapshot getMenu(UUID uuid, ResourceKey<Level> dimension, int tick) {
        return latestAt(MENUS, new MenuKey(uuid, dimension), tick);
    }

    public static ScreenSnapshot getScreen(UUID uuid, ResourceKey<Level> dimension, int tick) {
        return latestAt(SCREENS, new MenuKey(uuid, dimension), tick);
    }

    public static KeySnapshot getKeys(UUID uuid, ResourceKey<Level> dimension, int tick) {
        return latestAt(KEYS, new MenuKey(uuid, dimension), tick);
    }

    public static DeathSnapshot getDeath(UUID uuid, ResourceKey<Level> dimension, int tick) {
        return latestAt(DEATHS, new MenuKey(uuid, dimension), tick);
    }

    /**
     * Returns up to {@code count} most recent menu snapshots not after {@code tick}, but only
     * within the current open-menu session (stops at the previous "closed" marker). This keeps
     * the mouse trail from bleeding across separate openings of the same container.
     */
    public static List<MenuSnapshot> getRecentMenus(UUID uuid, ResourceKey<Level> dimension, int tick, int count) {
        List<Timed<MenuSnapshot>> list = MENUS.get(new MenuKey(uuid, dimension));
        if (list == null) {
            return List.of();
        }
        List<MenuSnapshot> out = new ArrayList<>();
        for (int i = list.size() - 1; i >= 0 && out.size() < count; i--) {
            Timed<MenuSnapshot> t = list.get(i);
            if (t.tick() > tick) {
                continue;
            }
            if (!t.value().open()) {
                break; // reached the previous "closed" marker - stop so we stay in this session
            }
            out.add(0, t.value());
        }
        return out;
    }

    public static void clear() {
        PLAYER_INV.clear();
        CONTAINER_INV.clear();
        MENUS.clear();
        SCREENS.clear();
        KEYS.clear();
        DEATHS.clear();
    }

    private static <K, V> void add(ConcurrentHashMap<K, List<Timed<V>>> map, K key, Timed<V> entry) {
        map.compute(key, (k, list) -> {
            if (list == null) {
                list = new ArrayList<>();
            }
            list.add(entry);
            return list;
        });
    }

    private static <K, V> V latestAt(ConcurrentHashMap<K, List<Timed<V>>> map, K key, int tick) {
        List<Timed<V>> list = map.get(key);
        if (list == null) {
            return null;
        }
        V found = null;
        // Index-based loop: lists only ever grow (never shrink during playback), so a concurrent
        // append by the recording thread cannot throw ConcurrentModificationException here.
        int n = list.size();
        for (int i = 0; i < n; i++) {
            Timed<V> t = list.get(i);
            if (t.tick() <= tick) {
                found = t.value();
            }
        }
        return found;
    }
}
