package com.flashbackinventory.gui;

import com.flashbackinventory.config.FlashbackInventoryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Simple configuration screen opened from Mod Menu. No external UI library required.
 */
public final class FlashbackInventoryConfigScreen extends Screen {

    private final Screen parent;

    public FlashbackInventoryConfigScreen(Screen parent) {
        super(Component.literal("Flashback Inventory Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        Button renderBtn = Button.builder(
                Component.literal("Render replay GUI: " + (FlashbackInventoryConfig.renderEnabled ? "ON" : "OFF")),
                b -> {
                    FlashbackInventoryConfig.renderEnabled = !FlashbackInventoryConfig.renderEnabled;
                    FlashbackInventoryConfig.save();
                    b.setMessage(Component.literal("Render replay GUI: "
                            + (FlashbackInventoryConfig.renderEnabled ? "ON" : "OFF")));
                }
        ).bounds(cx - 100, 34, 200, 20).build();
        this.addRenderableWidget(renderBtn);

        Button radiusBtn = Button.builder(
                Component.literal("Container scan radius: " + FlashbackInventoryConfig.containerScanRadius + " blocks"),
                b -> {
                    int r = FlashbackInventoryConfig.containerScanRadius + 8;
                    if (r > 64) {
                        r = 8;
                    }
                    FlashbackInventoryConfig.containerScanRadius = r;
                    FlashbackInventoryConfig.save();
                    b.setMessage(Component.literal("Container scan radius: "
                            + FlashbackInventoryConfig.containerScanRadius + " blocks"));
                }
        ).bounds(cx - 100, 59, 200, 20).build();
        this.addRenderableWidget(radiusBtn);

        Button done = Button.builder(Component.literal("Done"), b -> this.onClose())
                .bounds(cx - 100, this.height - 30, 200, 20).build();
        this.addRenderableWidget(done);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().gui.setScreen(parent);
    }
}
