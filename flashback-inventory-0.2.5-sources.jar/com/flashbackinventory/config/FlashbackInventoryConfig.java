package com.flashbackinventory.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Simple persistent config, loaded from / saved to the Fabric config directory
 * (config/flashback-inventory.json). Exposed through the Mod Menu screen.
 */
public final class FlashbackInventoryConfig {

    /** Container scan radius in blocks (issue 2.0: reward/loot chests far away were missed). */
    public static int containerScanRadius = 24;
    /** Whether the replay overlay redraws interfaces at all. */
    public static boolean renderEnabled = true;

    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir().resolve("flashback-inventory.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private record Data(int containerScanRadius, boolean renderEnabled) {
    }

    static {
        load();
    }

    private FlashbackInventoryConfig() {
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Data data = GSON.fromJson(Files.readString(FILE), Data.class);
                if (data != null) {
                    containerScanRadius = data.containerScanRadius();
                    renderEnabled = data.renderEnabled();
                }
            }
        } catch (Exception ignored) {
            // Best-effort; defaults are used on any failure.
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(new Data(containerScanRadius, renderEnabled)));
        } catch (Exception ignored) {
            // Best-effort.
        }
    }
}
