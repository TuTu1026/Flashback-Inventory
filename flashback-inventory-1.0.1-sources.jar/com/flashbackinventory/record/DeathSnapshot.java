package com.flashbackinventory.record;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.UUID;

/**
 * A snapshot marking whether a player was dead (or dying) at one tick while recording.
 * Replayed as a red/black full-screen filter until the player respawns.
 */
public record DeathSnapshot(
        ResourceKey<Level> dimension,
        UUID playerUuid,
        boolean dead
) implements CustomPacketPayload {

    public static final Type<DeathSnapshot> TYPE = new Type<>(
            Identifier.fromNamespaceAndPath("flashback_inventory", "death_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DeathSnapshot> STREAM_CODEC =
            StreamCodec.ofMember(DeathSnapshot::encode, DeathSnapshot::decode);

    private void encode(RegistryFriendlyByteBuf buf) {
        buf.writeResourceKey(this.dimension);
        buf.writeUUID(this.playerUuid);
        buf.writeBoolean(this.dead);
    }

    private static DeathSnapshot decode(RegistryFriendlyByteBuf buf) {
        ResourceKey<Level> dimension = buf.readResourceKey(Registries.DIMENSION);
        UUID uuid = buf.readUUID();
        boolean dead = buf.readBoolean();
        return new DeathSnapshot(dimension, uuid, dead);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
