package com.flashbackinventory.record;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * A snapshot of which movement/action keys were held down at one tick while recording.
 * Replayed as key chips in the bottom-right corner.
 */
public record KeySnapshot(
        ResourceKey<Level> dimension,
        UUID playerUuid,
        List<String> keys
) implements CustomPacketPayload {

    public static final Type<KeySnapshot> TYPE = new Type<>(
            Identifier.fromNamespaceAndPath("flashback_inventory", "key_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, KeySnapshot> STREAM_CODEC =
            StreamCodec.ofMember(KeySnapshot::encode, KeySnapshot::decode);

    private void encode(RegistryFriendlyByteBuf buf) {
        buf.writeResourceKey(this.dimension);
        buf.writeUUID(this.playerUuid);
        buf.writeVarInt(this.keys.size());
        for (String key : this.keys) {
            buf.writeUtf(key);
        }
    }

    private static KeySnapshot decode(RegistryFriendlyByteBuf buf) {
        ResourceKey<Level> dimension = buf.readResourceKey(Registries.DIMENSION);
        UUID uuid = buf.readUUID();
        int count = buf.readVarInt();
        List<String> keys = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            keys.add(buf.readUtf());
        }
        return new KeySnapshot(dimension, uuid, keys);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
