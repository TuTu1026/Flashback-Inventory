package com.flashbackinventory.record;

import io.netty.buffer.ByteBuf;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.UUID;

/**
 * A snapshot of a non-container screen GUI (creative inventory, game-mode switcher, chat)
 * captured at one tick. {@code open} marks the moment the screen was opened/closed; the extra
 * text carries the search query / selected game mode / chat input for display.
 */
public record ScreenSnapshot(
        ResourceKey<Level> dimension,
        UUID playerUuid,
        Identifier textureId,
        String title,
        boolean open,
        String extraText
) implements CustomPacketPayload {

    public static final Type<ScreenSnapshot> TYPE = new Type<>(
            Identifier.fromNamespaceAndPath("flashback_inventory", "screen_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ScreenSnapshot> STREAM_CODEC =
            StreamCodec.ofMember(ScreenSnapshot::encode, ScreenSnapshot::decode);

    private void encode(RegistryFriendlyByteBuf buf) {
        buf.writeResourceKey(this.dimension);
        buf.writeUUID(this.playerUuid);
        Identifier.STREAM_CODEC.encode(buf, this.textureId);
        buf.writeUtf(this.title);
        buf.writeBoolean(this.open);
        buf.writeUtf(this.extraText);
    }

    private static ScreenSnapshot decode(RegistryFriendlyByteBuf buf) {
        ResourceKey<Level> dimension = buf.readResourceKey(Registries.DIMENSION);
        UUID uuid = buf.readUUID();
        Identifier textureId = Identifier.STREAM_CODEC.decode(buf);
        String title = buf.readUtf();
        boolean open = buf.readBoolean();
        String extraText = buf.readUtf();
        return new ScreenSnapshot(dimension, uuid, textureId, title, open, extraText);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
