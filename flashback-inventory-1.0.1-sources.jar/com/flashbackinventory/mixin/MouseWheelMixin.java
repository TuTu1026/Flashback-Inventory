package com.flashbackinventory.mixin;

import com.flashbackinventory.record.InventoryRecorder;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Captures mouse-wheel events so the held-key display can show WheelUp / WheelDown.
 */
@Mixin(MouseHandler.class)
public abstract class MouseWheelMixin {

    @Inject(method = "onScroll", at = @At("HEAD"))
    private void flashbackinventory$onScroll(long window, double x, double y, CallbackInfo ci) {
        InventoryRecorder.onMouseWheel(y);
    }
}
