package com.flashbackinventory.action;

import com.flashbackinventory.record.KeySnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.action.Action;
import com.moulberry.flashback.playback.ReplayServer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.Identifier;

/**
 * Custom Flashback {@link Action} carrying a {@link KeySnapshot}.
 */
public final class ActionKeySnapshot implements Action {

    private static final Identifier NAME = Identifier.fromNamespaceAndPath(
            "flashback_inventory", "key_snapshot");

    public static final ActionKeySnapshot INSTANCE = new ActionKeySnapshot();

    private ActionKeySnapshot() {
    }

    @Override
    public Identifier name() {
        return NAME;
    }

    @Override
    public void handle(ReplayServer replayServer, RegistryFriendlyByteBuf buf) {
        KeySnapshot snapshot = KeySnapshot.STREAM_CODEC.decode(buf);
        ReplayInventoryStore.putKeys(replayServer.getReplayTick(), snapshot);
    }
}
