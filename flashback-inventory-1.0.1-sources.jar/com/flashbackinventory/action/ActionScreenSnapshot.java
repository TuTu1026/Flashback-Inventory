package com.flashbackinventory.action;

import com.flashbackinventory.record.ScreenSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.action.Action;
import com.moulberry.flashback.playback.ReplayServer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.Identifier;

/**
 * Custom Flashback {@link Action} carrying a {@link ScreenSnapshot}.
 */
public final class ActionScreenSnapshot implements Action {

    private static final Identifier NAME = Identifier.fromNamespaceAndPath(
            "flashback_inventory", "screen_snapshot");

    public static final ActionScreenSnapshot INSTANCE = new ActionScreenSnapshot();

    private ActionScreenSnapshot() {
    }

    @Override
    public Identifier name() {
        return NAME;
    }

    @Override
    public void handle(ReplayServer replayServer, RegistryFriendlyByteBuf buf) {
        ScreenSnapshot snapshot = ScreenSnapshot.STREAM_CODEC.decode(buf);
        ReplayInventoryStore.putScreen(replayServer.getReplayTick(), snapshot);
    }
}
