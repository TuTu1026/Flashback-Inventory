package com.flashbackinventory.action;

import com.flashbackinventory.record.DeathSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.action.Action;
import com.moulberry.flashback.playback.ReplayServer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.Identifier;

/**
 * Custom Flashback {@link Action} carrying a {@link DeathSnapshot}.
 */
public final class ActionDeathSnapshot implements Action {

    private static final Identifier NAME = Identifier.fromNamespaceAndPath(
            "flashback_inventory", "death_snapshot");

    public static final ActionDeathSnapshot INSTANCE = new ActionDeathSnapshot();

    private ActionDeathSnapshot() {
    }

    @Override
    public Identifier name() {
        return NAME;
    }

    @Override
    public void handle(ReplayServer replayServer, RegistryFriendlyByteBuf buf) {
        DeathSnapshot snapshot = DeathSnapshot.STREAM_CODEC.decode(buf);
        ReplayInventoryStore.putDeath(replayServer.getReplayTick(), snapshot);
    }
}
