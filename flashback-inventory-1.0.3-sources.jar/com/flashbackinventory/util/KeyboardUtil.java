package com.flashbackinventory.util;

import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * GLFW keyboard helper for MC 26.2 (which ships LWJGL-GLFW, unlike 26.3 which uses SDL).
 * Provides held-key polling, display names (with left/right modifier prefixes) and the
 * first-pressed-key detection used by the overlay-toggle keybinding.
 */
public final class KeyboardUtil {

    private KeyboardUtil() {
    }

    private static long window() {
        try {
            return Minecraft.getInstance().getWindow().handle();
        } catch (Throwable t) {
            return 0L;
        }
    }

    /** Whether the given GLFW key code is currently held. */
    public static boolean isKeyDown(int keyCode) {
        if (keyCode <= 0) {
            return false;
        }
        try {
            long win = window();
            return win != 0L && GLFW.glfwGetKey(win, keyCode) == GLFW.GLFW_PRESS;
        } catch (Throwable t) {
            return false;
        }
    }

    /** All currently-held key display names (left/right modifiers prefixed). */
    public static Set<String> keysDown() {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        try {
            long win = window();
            if (win == 0L) {
                return out;
            }
            for (int code = 0; code <= GLFW.GLFW_KEY_LAST; code++) {
                if (GLFW.glfwGetKey(win, code) == GLFW.GLFW_PRESS) {
                    String n = keyName(code);
                    if (n != null) {
                        out.add(n);
                    }
                }
            }
        } catch (Throwable ignored) {
            // Best-effort.
        }
        return out;
    }

    /** First currently-pressed GLFW key code, or -1 if none (for keybinding capture). */
    public static int pressedKeyCode() {
        try {
            long win = window();
            if (win == 0L) {
                return -1;
            }
            for (int code = 0; code <= GLFW.GLFW_KEY_LAST; code++) {
                if (GLFW.glfwGetKey(win, code) == GLFW.GLFW_PRESS) {
                    return code;
                }
            }
        } catch (Throwable ignored) {
            // Best-effort.
        }
        return -1;
    }

    /** Display name for a GLFW key code, or null if unknown. */
    public static String keyName(int code) {
        switch (code) {
            case GLFW.GLFW_KEY_SPACE: return "Space";
            case GLFW.GLFW_KEY_ENTER: return "Enter";
            case GLFW.GLFW_KEY_ESCAPE: return "Esc";
            case GLFW.GLFW_KEY_TAB: return "Tab";
            case GLFW.GLFW_KEY_BACKSPACE: return "Backspace";
            case GLFW.GLFW_KEY_DELETE: return "Del";
            case GLFW.GLFW_KEY_INSERT: return "Ins";
            case GLFW.GLFW_KEY_HOME: return "Home";
            case GLFW.GLFW_KEY_END: return "End";
            case GLFW.GLFW_KEY_PAGE_UP: return "PgUp";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PgDn";
            case GLFW.GLFW_KEY_CAPS_LOCK: return "CapsLock";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LShift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RShift";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCtrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCtrl";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LAlt";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RAlt";
            case GLFW.GLFW_KEY_GRAVE_ACCENT: return "`";
            case GLFW.GLFW_KEY_UP: return "Up";
            case GLFW.GLFW_KEY_DOWN: return "Down";
            case GLFW.GLFW_KEY_LEFT: return "Left";
            case GLFW.GLFW_KEY_RIGHT: return "Right";
        }
        if (code >= GLFW.GLFW_KEY_A && code <= GLFW.GLFW_KEY_Z) {
            return String.valueOf((char) ('A' + (code - GLFW.GLFW_KEY_A)));
        }
        if (code >= GLFW.GLFW_KEY_0 && code <= GLFW.GLFW_KEY_9) {
            return String.valueOf((char) ('0' + (code - GLFW.GLFW_KEY_0)));
        }
        if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F25) {
            return "F" + (code - GLFW.GLFW_KEY_F1 + 1);
        }
        if (code >= GLFW.GLFW_KEY_KP_0 && code <= GLFW.GLFW_KEY_KP_9) {
            return "KP" + (code - GLFW.GLFW_KEY_KP_0);
        }
        return null;
    }
}
