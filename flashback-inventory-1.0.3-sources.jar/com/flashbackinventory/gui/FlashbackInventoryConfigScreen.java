package com.flashbackinventory.gui;

import com.flashbackinventory.FlashbackInventory;
import com.flashbackinventory.config.FlashbackInventoryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Configuration screen with a left-hand category navigation and a right-hand detail panel,
 * mirroring Flashback's own settings layout. Categories: Language, Recording, Rendering,
 * Keybind and Author. Numeric settings can be toggled between text input and a slider ("/"),
 * precision 1; GUI depth / background opacity have live colour previews.
 */
public final class FlashbackInventoryConfigScreen extends Screen {

    private static final Map<String, String> ZH_NAMES = new HashMap<>();

    static {
        ZH_NAMES.put("inventory", "物品栏");
        ZH_NAMES.put("chest", "箱子");
        ZH_NAMES.put("crafting_table", "工作台");
        ZH_NAMES.put("furnace", "熔炉");
        ZH_NAMES.put("smoker", "烟熏炉");
        ZH_NAMES.put("blast_furnace", "高炉");
        ZH_NAMES.put("brewing_stand", "酿造台");
        ZH_NAMES.put("enchanting_table", "附魔台");
        ZH_NAMES.put("anvil", "铁砧");
        ZH_NAMES.put("beacon", "信标");
        ZH_NAMES.put("grindstone", "磨石");
        ZH_NAMES.put("cartography_table", "制图台");
        ZH_NAMES.put("loom", "织布机");
        ZH_NAMES.put("smithing", "锻造台");
        ZH_NAMES.put("stonecutter", "切石机");
        ZH_NAMES.put("dispenser", "发射器");
        ZH_NAMES.put("hopper", "漏斗");
        ZH_NAMES.put("shulker_box", "潜影盒");
        ZH_NAMES.put("horse", "马");
        ZH_NAMES.put("villager", "村民");
        ZH_NAMES.put("crafter", "合成器");
    }

    private static final int TAB_LANGUAGE = 0;
    private static final int TAB_RECORDING = 1;
    private static final int TAB_RENDERING = 2;
    private static final int TAB_KEYBIND = 3;
    private static final int TAB_AUTHOR = 4;
    private static final int LEFT_W = 110;
    private static final int RIGHT_X = 126;

    /** True while waiting for the user to press the key that toggles the replay overlay. */
    private static boolean bindMode = false;
    /** Currently selected left-hand category. */
    private static int currentTab = TAB_LANGUAGE;

    private final Screen parent;
    private ColorPreview alphaPreview;
    private ColorPreview bgPreview;

    /** Scroll offset (<= 0). Kept static so rebuilds keep the position within the current tab. */
    private static int scrollY = 0;
    private static int contentHeight = 0;

    public FlashbackInventoryConfigScreen(Screen parent) {
        super(Component.literal("Flashback Inventory Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int y = 8;
        // Left-hand category navigation (labels stay English, matching "Language" lock).
        String[] tabs = { "Language", t("Recording", "录制"), t("Rendering", "渲染"),
                t("Keybind", "键位设置"), t("Author", "作者") };
        for (int i = 0; i < tabs.length; i++) {
            final int idx = i;
            Button b = Button.builder(Component.literal((currentTab == i ? "> " : "") + tabs[i]), btn -> {
                currentTab = idx;
                scrollY = 0;
                rebuildButtons();
            }).bounds(10, y, LEFT_W, 20).build();
            this.addRenderableWidget(b);
            y += 22;
        }

        // Clamp scroll for the right-hand panel.
        int maxScroll = Math.max(0, contentHeight + 24 - (this.height - 34));
        scrollY = Math.max(-maxScroll, Math.min(0, scrollY));
        int ry = 8 + scrollY;

        switch (currentTab) {
            case TAB_LANGUAGE -> renderLanguage(ry);
            case TAB_RECORDING -> renderRecording(ry);
            case TAB_RENDERING -> renderRendering(ry);
            case TAB_KEYBIND -> renderKeybind(ry);
            case TAB_AUTHOR -> renderAuthor(ry);
            default -> renderLanguage(ry);
        }
        contentHeight = ry;
    }

    /** Language category: switch between English and 中文. */
    private void renderLanguage(int y) {
        Button langBtn = Button.builder(Component.literal(t("Language: English", "语言：中文")), b -> {
            FlashbackInventoryConfig.language = FlashbackInventoryConfig.language.equals("zh") ? "en" : "zh";
            FlashbackInventoryConfig.save();
            rebuildButtons();
        }).bounds(RIGHT_X, y, 260, 18).build();
        this.addRenderableWidget(langBtn);
    }

    /** Recording category: what gets recorded (containers, mouse trail, keys, chat). */
    private void renderRecording(int y) {
        addToggle(RIGHT_X, y, 260, () -> FlashbackInventoryConfig.recordMouseTrail,
                v -> FlashbackInventoryConfig.recordMouseTrail = v,
                t("Record mouse trail", "录制鼠标轨迹"));
        y += 20;
        addToggle(RIGHT_X, y, 260, () -> FlashbackInventoryConfig.recordChat,
                v -> FlashbackInventoryConfig.recordChat = v,
                t("Record chat", "录制聊天"));
        y += 20;
        addToggle(RIGHT_X, y, 260, () -> FlashbackInventoryConfig.recordKeys,
                v -> FlashbackInventoryConfig.recordKeys = v,
                t("Record key display", "录制按键显示"));
        y += 22;

        // Select all / none.
        Button allBtn = Button.builder(Component.literal(t("Select all", "全选")), b -> {
            for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
                FlashbackInventoryConfig.containerEnabled.put(key, true);
            }
            FlashbackInventoryConfig.save();
            rebuildButtons();
        }).bounds(RIGHT_X, y, 125, 18).build();
        this.addRenderableWidget(allBtn);
        Button noneBtn = Button.builder(Component.literal(t("Select none", "全不选")), b -> {
            for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
                FlashbackInventoryConfig.containerEnabled.put(key, false);
            }
            FlashbackInventoryConfig.save();
            rebuildButtons();
        }).bounds(RIGHT_X + 130, y, 130, 18).build();
        this.addRenderableWidget(noneBtn);
        y += 22;

        // Per-container toggles.
        for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
            String k = key;
            Button cb = Button.builder(Component.literal(containerLabel(k)), b -> {
                boolean v = FlashbackInventoryConfig.containerEnabled.getOrDefault(k, true);
                FlashbackInventoryConfig.containerEnabled.put(k, !v);
                FlashbackInventoryConfig.save();
                b.setMessage(Component.literal(containerLabel(k)));
            }).bounds(RIGHT_X, y, 260, 16).build();
            this.addRenderableWidget(cb);
            y += 18;
        }
    }

    /** Rendering category: colours, trail length, fade, death filter (locked to red). */
    private void renderRendering(int y) {
        addToggle(RIGHT_X, y, 260, () -> FlashbackInventoryConfig.renderEnabled,
                v -> FlashbackInventoryConfig.renderEnabled = v,
                t("Render replay GUI", "回放渲染GUI"));
        y += 20;
        numericRow(y, "guiPanelAlpha", t("GUI depth", "GUI深浅"), 0, 255,
                v -> FlashbackInventoryConfig.guiPanelAlpha = v);
        y += 20;
        numericRow(y, "backgroundAlpha", t("Background opacity", "背景不透明度"), 0, 255,
                v -> FlashbackInventoryConfig.backgroundAlpha = v);
        y += 20;
        numericRow(y, "trailLength", t("Trail tail length", "轨迹尾巴长度"), 0, 10,
                v -> FlashbackInventoryConfig.trailLength = v);
        y += 20;
        numericRow(y, "keyFadeTicks", t("Key fade duration", "按键淡入淡出时长"), 0, 60,
                v -> FlashbackInventoryConfig.keyFadeTicks = v);
    }

    /** Keybind category: the single overlay-toggle key. */
    private void renderKeybind(int y) {
        Button keyBtn = Button.builder(Component.literal(
                bindMode ? t("Press any key...", "按下任意键...") : toggleKeyLabel()), b -> {
            if (bindMode) {
                bindMode = false;
                rebuildButtons();
            } else {
                bindMode = true;
                b.setMessage(Component.literal(t("Press any key...", "按下任意键...")));
            }
        }).bounds(RIGHT_X, y, 260, 18).build();
        this.addRenderableWidget(keyBtn);
    }

    /** Author category: link to the author's Bilibili space. */
    private void renderAuthor(int y) {
        Button authorBtn = Button.builder(Component.literal(
                t("Author（" + AUTHOR_URL + "）", "作者（" + AUTHOR_URL + "）")), b -> openLink(AUTHOR_URL))
                .bounds(RIGHT_X, y, 300, 18).build();
        this.addRenderableWidget(authorBtn);
    }

    private static final String AUTHOR_URL = "https://space.bilibili.com/1686417568";

    /** Opens a web link using the OS default browser, with a command-line fallback. */
    private static void openLink(String url) {
        try {
            java.awt.Desktop dt = java.awt.Desktop.getDesktop();
            if (dt != null && dt.isSupported(java.awt.Desktop.Action.BROWSE)) {
                dt.browse(new java.net.URI(url));
                return;
            }
        } catch (Throwable e) {
            FlashbackInventory.LOGGER.warn("[Flashback Inventory] Desktop browse failed: {}", e.toString());
        }
        try {
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("win")) {
                new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start();
            } else if (os.contains("mac")) {
                new ProcessBuilder("open", url).start();
            } else {
                new ProcessBuilder("xdg-open", url).start();
            }
        } catch (Throwable e) {
            FlashbackInventory.LOGGER.warn("[Flashback Inventory] open browser fallback failed: {}", e.toString());
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!bindMode) {
            return;
        }
        int code = com.flashbackinventory.util.KeyboardUtil.pressedKeyCode();
        if (code > 0) {
            FlashbackInventoryConfig.overlayToggleScancode = code;
            FlashbackInventoryConfig.save();
            bindMode = false;
            rebuildButtons();
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        int maxScroll = Math.max(0, contentHeight + 24 - (this.height - 34));
        int newY = (int) Math.round(scrollY + vertical * 18);
        newY = Math.max(-maxScroll, Math.min(0, newY));
        if (newY != scrollY) {
            scrollY = newY;
            rebuildButtons();
        }
        return true;
    }

    private static String toggleKeyLabel() {
        int sc = FlashbackInventoryConfig.overlayToggleScancode;
        String name = sc > 0 ? com.flashbackinventory.util.KeyboardUtil.keyName(sc) : null;
        String keyName = (name == null || name.isEmpty()) ? "None" : name;
        return FlashbackInventoryConfig.language.equals("zh")
                ? "全局渲染开关: " + keyName : "Overlay toggle key: " + keyName;
    }

    /** A full-width ON/OFF toggle button in the right-hand panel. */
    private void addToggle(int x, int y, int w, java.util.function.BooleanSupplier get,
                           Consumer<Boolean> set, String base) {
        Button b = Button.builder(Component.literal(base + ": " + onoff(get.getAsBoolean())), btn -> {
            set.accept(!get.getAsBoolean());
            FlashbackInventoryConfig.save();
            btn.setMessage(Component.literal(base + ": " + onoff(get.getAsBoolean())));
        }).bounds(x, y, w, 18).build();
        this.addRenderableWidget(b);
    }

    /** A numeric row: label button (shows value) + "/" mode toggle + EditBox or Slider. */
    private void numericRow(int y, String key, String label, int min, int max, Consumer<Integer> setter) {
        boolean preview = key.equals("guiPanelAlpha") || key.equals("backgroundAlpha");
        Label lbl = new Label(RIGHT_X, y, 150, 18, label + " = " + valueOf(key));
        this.addRenderableWidget(lbl);

        Runnable refresh = () -> {
            lbl.setText(label + " = " + valueOf(key));
            if (alphaPreview != null) {
                alphaPreview.color = (FlashbackInventoryConfig.guiPanelAlpha << 24);
            }
            if (bgPreview != null) {
                bgPreview.color = (FlashbackInventoryConfig.backgroundAlpha << 24);
            }
            FlashbackInventoryConfig.save();
        };

        if (preview) {
            ColorPreview cp = new ColorPreview(RIGHT_X + 152, y + 1, 14, 16,
                    (FlashbackInventoryConfig.guiPanelAlpha << 24));
            if (key.equals("guiPanelAlpha")) {
                alphaPreview = cp;
                cp.color = (FlashbackInventoryConfig.guiPanelAlpha << 24);
            } else {
                bgPreview = cp;
                cp.color = (FlashbackInventoryConfig.backgroundAlpha << 24);
            }
            this.addRenderableWidget(cp);
        }

        Button slash = Button.builder(Component.literal("/"), b -> {
            boolean newMode = !FlashbackInventoryConfig.editMode.getOrDefault(key, false);
            FlashbackInventoryConfig.editMode.put(key, newMode);
            rebuildButtons();
        }).bounds(preview ? RIGHT_X + 168 : RIGHT_X + 152, y, 18, 18).build();
        this.addRenderableWidget(slash);

        int editX = preview ? RIGHT_X + 188 : RIGHT_X + 172;
        boolean sliderMode = FlashbackInventoryConfig.editMode.getOrDefault(key, false);
        if (sliderMode) {
            this.addRenderableWidget(new NumSlider(editX, y, 100, 18, min, max, valueOf(key),
                    v -> {
                        setter.accept(v);
                        refresh.run();
                    }));
        } else {
            EditBox eb = new EditBox(this.font, editX, y + 1, 100, 16, Component.literal(""));
            eb.setMaxLength(3);
            eb.setValue(String.valueOf(valueOf(key)));
            eb.setResponder(s -> {
                try {
                    int v = Integer.parseInt(s.trim());
                    v = Math.max(min, Math.min(max, v));
                    setter.accept(v);
                    refresh.run();
                } catch (NumberFormatException ignored) {
                    // keep typing until a valid number
                }
            });
            this.addRenderableWidget(eb);
        }
    }

    private static int valueOf(String key) {
        return switch (key) {
            case "trailLength" -> FlashbackInventoryConfig.trailLength;
            case "containerScanRadius" -> FlashbackInventoryConfig.containerScanRadius;
            case "guiPanelAlpha" -> FlashbackInventoryConfig.guiPanelAlpha;
            case "backgroundAlpha" -> FlashbackInventoryConfig.backgroundAlpha;
            case "keyFadeTicks" -> FlashbackInventoryConfig.keyFadeTicks;
            default -> 0;
        };
    }

    private void rebuildButtons() {
        Minecraft.getInstance().gui.setScreen(new FlashbackInventoryConfigScreen(parent));
    }

    private static String containerLabel(String key) {
        String name = FlashbackInventoryConfig.language.equals("zh")
                ? ZH_NAMES.getOrDefault(key, key)
                : key;
        return name + ":" + onoff(FlashbackInventoryConfig.containerEnabled.getOrDefault(key, true));
    }

    private static String onoff(boolean on) {
        return on ? (FlashbackInventoryConfig.language.equals("zh") ? "开" : "ON")
                : (FlashbackInventoryConfig.language.equals("zh") ? "关" : "OFF");
    }

    private static String t(String en, String zh) {
        return FlashbackInventoryConfig.language.equals("zh") ? zh : en;
    }

    @Override
    public void onClose() {
        bindMode = false;
        Minecraft.getInstance().gui.setScreen(parent);
    }

    /** Numeric slider, precision 1. */
    private static final class NumSlider extends AbstractSliderButton {
        private final int min;
        private final int max;
        private final Consumer<Integer> apply;

        NumSlider(int x, int y, int w, int h, int min, int max, int current, Consumer<Integer> apply) {
            super(x, y, w, h, Component.literal(""), (max > min) ? (current - min) / (double) (max - min) : 0.0);
            this.min = min;
            this.max = max;
            this.apply = apply;
            updateMessage();
        }

        private int current() {
            return (int) Math.round(min + this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(String.valueOf(current())));
        }

        @Override
        protected void applyValue() {
            apply.accept(current());
        }
    }

    /** Small solid colour swatch used as an opacity preview. */
    private static final class ColorPreview extends AbstractWidget {
        private int color;

        ColorPreview(int x, int y, int w, int h, int color) {
            super(x, y, w, h, Component.empty());
            this.color = color;
        }

        @Override
        protected void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
            g.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), color);
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
        }
    }

    /** Non-interactive text row (drawn as plain text, not a button). */
    private static final class Label extends AbstractWidget {
        private String text;

        Label(int x, int y, int w, int h, String text) {
            super(x, y, w, h, Component.literal(text));
            this.text = text;
        }

        void setText(String text) {
            this.text = text;
        }

        @Override
        protected void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
            g.text(net.minecraft.client.Minecraft.getInstance().font, text,
                    getX(), getY() + (getHeight() - 8) / 2, 0xFFFFFFFF);
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
        }
    }
}
