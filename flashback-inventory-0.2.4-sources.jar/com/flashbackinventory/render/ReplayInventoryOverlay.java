package com.flashbackinventory.render;

import com.flashbackinventory.FlashbackInventory;
import com.flashbackinventory.config.FlashbackInventoryConfig;
import com.flashbackinventory.record.MenuSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.flashbackinventory.texture.GuiTextureCache;
import com.moulberry.flashback.Flashback;
import com.moulberry.flashback.playback.ReplayServer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Redraws the recorded GUI in the centre of the screen, but only while:
 * <ul>
 *   <li>a Flashback replay is playing back, and</li>
 *   <li>the viewer is spectating a player's first-person view, and</li>
 *   <li>that player had a container/inventory menu open at the current replay tick.</li>
 * </ul>
 * The panel uses a translucent dark background so the world stays visible behind it.
 */
public final class ReplayInventoryOverlay implements HudElement {

    public static final Identifier ID = FlashbackInventory.id("replay_inventory_overlay");

    /** Toggleable via the mod keybind. */
    public static volatile boolean enabled = true;

    /** Shared condition used by the overlay and the crosshair-hiding mixin. */
    public static boolean isGuiVisible() {
        if (!enabled || !FlashbackInventoryConfig.renderEnabled || !Flashback.isInReplay()) {
            return false;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return false;
        }
        if (!minecraft.options.getCameraType().isFirstPerson()) {
            return false;
        }
        if (!(minecraft.getCameraEntity() instanceof Player player)) {
            return false;
        }
        ReplayServer server = Flashback.getReplayServer();
        if (server == null) {
            return false;
        }
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        return menu != null && menu.open();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        if (!isGuiVisible()) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        Player player = (Player) minecraft.getCameraEntity();
        ReplayServer server = Flashback.getReplayServer();
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        if (menu == null) {
            return;
        }
        drawMenu(extractor, minecraft, menu);
    }

    private void drawMenu(GuiGraphicsExtractor extractor, Minecraft minecraft, MenuSnapshot menu) {
        int width = menu.width();
        int height = menu.height();
        int x = (minecraft.getWindow().getGuiScaledWidth() - width) / 2;
        int y = (minecraft.getWindow().getGuiScaledHeight() - height) / 2;

        // Translucent world background: the whole screen is dimmed so the GUI floats on top
        // while the world behind stays (dimly) visible.
        extractor.fill(0, 0, minecraft.getWindow().getGuiScaledWidth(),
                minecraft.getWindow().getGuiScaledHeight(), 0x55000000);

        // Real GUI texture panel (opaque). Falls back to a translucent panel if it can't load.
        if (menu.textureId() != null) {
            GuiTextureCache.ensureLoaded(menu.textureId());
            extractor.blit(menu.textureId(), x, y, width, height, 0.0f, 0.0f, 1.0f, 1.0f);
        }
        extractor.fill(x, y, x + width, y + height, 0x33000000);

        // Item icons + stack counts.
        Font font = minecraft.font;
        for (MenuSnapshot.MenuSlotData s : menu.slots()) {
            int sx = x + s.x();
            int sy = y + s.y();
            ItemStack stack = s.stack();
            extractor.item(stack, sx + 1, sy + 1);
            extractor.itemDecorations(font, stack, sx + 1, sy + 1);
        }

        // Menu title.
        if (menu.title() != null && !menu.title().isEmpty()) {
            extractor.text(font, menu.title(), x + 8, y + 6, 0xFFFFFFFF);
        }
    }
}
