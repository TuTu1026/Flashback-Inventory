package com.flashbackinventory.record;

import com.flashbackinventory.action.ActionInventorySnapshot;
import com.flashbackinventory.action.ActionKeySnapshot;
import com.flashbackinventory.action.ActionMenuSnapshot;
import com.flashbackinventory.action.ActionScreenSnapshot;
import com.flashbackinventory.config.FlashbackInventoryConfig;
import com.moulberry.flashback.Flashback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.BeaconMenu;
import net.minecraft.world.inventory.BlastFurnaceMenu;
import net.minecraft.world.inventory.BrewingStandMenu;
import net.minecraft.world.inventory.CartographyTableMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.CrafterMenu;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.inventory.DispenserMenu;
import net.minecraft.world.inventory.EnchantmentMenu;
import net.minecraft.world.inventory.FurnaceMenu;
import net.minecraft.world.inventory.GrindstoneMenu;
import net.minecraft.world.inventory.HopperMenu;
import net.minecraft.world.inventory.HorseInventoryMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.LoomMenu;
import net.minecraft.world.inventory.MerchantMenu;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.SmithingMenu;
import net.minecraft.world.inventory.SmokerMenu;
import net.minecraft.world.inventory.StonecutterMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Captures player inventory, container and open-menu data while Flashback is recording, and writes
 * them into the replay file as {@link ActionInventorySnapshot} / {@link ActionMenuSnapshot} actions,
 * each tagged with the current recording tick.
 */
public final class InventoryRecorder {

    /** How often (in ticks) the nearby-container scan runs. */
    private static final int CONTAINER_SCAN_INTERVAL = 10;

    private static int tickCounter = 0;
    private static int lastPlayerHash = 0;
    private static final Map<BlockPos, Integer> lastContainerHashes = new HashMap<>();
    private static boolean lastMenuOpen = false;
    private static boolean lastScreenOpen = false;
    private static List<String> lastKeysDown = new ArrayList<>();

    private InventoryRecorder() {
    }

    /** Called every client tick. No-op unless Flashback is actively recording. */
    public static void onClientTick() {
        if (Flashback.RECORDER == null || !Flashback.RECORDER.readyToWrite()) {
            return;
        }
        if (Flashback.isInReplay()) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return;
        }
        ResourceKey<Level> dimension = minecraft.level.dimension();

        capturePlayer(minecraft, dimension);
        captureScreen(minecraft, dimension);
        captureMenu(minecraft, dimension);
        captureKeys(minecraft, dimension);
        if (++tickCounter % CONTAINER_SCAN_INTERVAL == 0) {
            captureContainers(minecraft, dimension);
        }
    }

    // ------------------------------------------------------------------
    // Player inventory
    // ------------------------------------------------------------------

    private static void capturePlayer(Minecraft minecraft, ResourceKey<Level> dimension) {
        LocalPlayer player = minecraft.player;
        Inventory inventory = player.getInventory();

        Map<Integer, ItemStack> slots = new LinkedHashMap<>();
        // Main inventory: slots 0-35.
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty()) slots.put(i, stack.copy());
        }
        // Armor: inventory UI order FEET(36), LEGS(37), CHEST(38), HEAD(39).
        slots.put(36, player.getItemBySlot(EquipmentSlot.FEET).copy());
        slots.put(37, player.getItemBySlot(EquipmentSlot.LEGS).copy());
        slots.put(38, player.getItemBySlot(EquipmentSlot.CHEST).copy());
        slots.put(39, player.getItemBySlot(EquipmentSlot.HEAD).copy());
        // Offhand: slot 40.
        slots.put(40, player.getItemBySlot(EquipmentSlot.OFFHAND).copy());

        int hash = hashOf(slots);
        if (hash != lastPlayerHash) {
            lastPlayerHash = hash;
            submitPlayer(tickCounter, InventorySnapshot.ofPlayer(dimension, player.getUUID(), slots));
        }
    }

    // ------------------------------------------------------------------
    // Open screen (non-container GUI) snapshots - creative, gamemode switcher, chat
    // ------------------------------------------------------------------

    private static void captureScreen(Minecraft minecraft, ResourceKey<Level> dimension) {
        Player player = minecraft.player;
        UUID uuid = player.getUUID();
        Screen screen = minecraft.gui.screen();

        // On death force-close any open GUI so playback doesn't hang on a stale interface.
        if (player.isDeadOrDying()) {
            if (lastScreenOpen) {
                submitScreen(tickCounter, new ScreenSnapshot(dimension, uuid, guiTexture("chat"), "", false, ""));
                lastScreenOpen = false;
            }
            return;
        }

        Identifier texture = null;
        String title = "";
        String extra = "";
        if (screen instanceof ChatScreen && FlashbackInventoryConfig.recordChat) {
            texture = guiTexture("chat");
            title = "Chat";
            extra = readEditBox(screen, "input");
        }

        if (texture == null) {
            if (lastScreenOpen) {
                submitScreen(tickCounter, new ScreenSnapshot(dimension, uuid, guiTexture("chat"), "", false, ""));
                lastScreenOpen = false;
            }
            return;
        }
        submitScreen(tickCounter, new ScreenSnapshot(dimension, uuid, texture, title, true, extra));
        lastScreenOpen = true;
    }

    /** Reads an EditBox-typed field by name via reflection (empty string on failure). */
    private static String readEditBox(Object owner, String field) {
        try {
            java.lang.reflect.Field f = owner.getClass().getDeclaredField(field);
            f.setAccessible(true);
            Object v = f.get(owner);
            if (v instanceof EditBox eb) {
                return eb.getValue();
            }
            return v == null ? "" : v.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    // ------------------------------------------------------------------
    // Held-key snapshots (bottom-right key display)
    // ------------------------------------------------------------------

    private static void captureKeys(Minecraft minecraft, ResourceKey<Level> dimension) {
        Player player = minecraft.player;
        UUID uuid = player.getUUID();
        if (!FlashbackInventoryConfig.recordKeys || player.isDeadOrDying()) {
            if (!lastKeysDown.isEmpty()) {
                lastKeysDown = List.of();
                submitKeys(tickCounter, new KeySnapshot(dimension, uuid, List.of()));
            }
            return;
        }
        java.util.LinkedHashSet<String> down = new java.util.LinkedHashSet<>();
        net.minecraft.client.Options opts = minecraft.options;
        if (opts.keyUp.isDown()) down.add("W");
        if (opts.keyDown.isDown()) down.add("S");
        if (opts.keyLeft.isDown()) down.add("A");
        if (opts.keyRight.isDown()) down.add("D");
        if (opts.keyJump.isDown()) down.add("Space");
        if (opts.keyShift.isDown()) down.add("Shift");
        if (opts.keySprint.isDown()) down.add("Ctrl");
        if (opts.keyAttack.isDown()) down.add("Mouse1");
        if (opts.keyUse.isDown()) down.add("Mouse2");
        if (opts.keyInventory.isDown()) down.add("E");
        List<String> list = new ArrayList<>(down);
        // Only write when the held-key set changes (including becoming empty on release).
        if (!list.equals(lastKeysDown)) {
            lastKeysDown = list;
            submitKeys(tickCounter, new KeySnapshot(dimension, uuid, lastKeysDown));
        }
    }

    private static void submitKeys(int tick, KeySnapshot snapshot) {
        submit(writer -> {
            writer.startAction(ActionKeySnapshot.INSTANCE);
            KeySnapshot.STREAM_CODEC.encode(writer.friendlyByteBuf(), snapshot);
            writer.finishAction(ActionKeySnapshot.INSTANCE);
        });
    }

    // ------------------------------------------------------------------
    // Open menu (GUI) snapshots - also covers crafting-table recipes
    // ------------------------------------------------------------------

    private static void captureMenu(Minecraft minecraft, ResourceKey<Level> dimension) {
        Player player = minecraft.player;
        UUID uuid = player.getUUID();

        // On death force-close any open container menu.
        if (player.isDeadOrDying()) {
            if (lastMenuOpen) {
                MenuSnapshot closed = new MenuSnapshot(
                        dimension, uuid, guiTexture("inventory"), "", 0, 0,
                        false, 0.0f, 0.0f, ItemStack.EMPTY, List.of());
                submitMenu(tickCounter, closed);
                lastMenuOpen = false;
            }
            return;
        }

        // Determine which menu is currently open (if any).
        AbstractContainerMenu menu = null;
        Identifier texture = null;
        String title = null;
        if (minecraft.gui.screen() != null) {
            if (minecraft.gui.screen() instanceof InventoryScreen) {
                menu = player.inventoryMenu;
                texture = guiTexture("inventory");
                title = minecraft.gui.screen().getTitle().getString(); // follows game language ("物品栏" in zh)
            } else {
                AbstractContainerMenu container = player.containerMenu;
                if (container != player.inventoryMenu) {
                    Identifier t = textureForMenu(container);
                    if (t != null) {
                        menu = container;
                        texture = t;
                        title = minecraft.gui.screen().getTitle().getString();
                    }
                }
            }
        }

        // Respect per-container-type recording toggles.
        if (texture != null) {
            String key = textureKey(texture);
            if (key != null && !FlashbackInventoryConfig.containerEnabled.getOrDefault(key, true)) {
                if (lastMenuOpen) {
                    MenuSnapshot closed = new MenuSnapshot(
                            dimension, uuid, guiTexture("inventory"), "", 0, 0,
                            false, 0.0f, 0.0f, ItemStack.EMPTY, List.of());
                    submitMenu(tickCounter, closed);
                    lastMenuOpen = false;
                }
                return;
            }
        }

        if (menu == null) {
            // No menu open: if one was open last tick it just closed, so write a "closed" marker
            // that tells playback to stop drawing the interface.
            if (lastMenuOpen) {
                MenuSnapshot closed = new MenuSnapshot(
                        dimension, uuid, guiTexture("inventory"), "", 0, 0,
                        false, 0.0f, 0.0f, ItemStack.EMPTY, List.of());
                submitMenu(tickCounter, closed);
                lastMenuOpen = false;
            }
            return;
        }

        // Menu open: collect ALL slots (empty ones included so empty slots render as wells),
        // plus the player's mouse position and the item currently held by the cursor.
        List<MenuSnapshot.MenuSlotData> slots = new ArrayList<>();
        int maxX = 0;
        int maxY = 0;
        for (Slot slot : menu.slots) {
            slots.add(new MenuSnapshot.MenuSlotData(slot.x, slot.y, slot.getItem().copy()));
            maxX = Math.max(maxX, slot.x + 18);
            maxY = Math.max(maxY, slot.y + 18);
        }
        int width = Math.max(176, maxX);
        int height = Math.max(166, maxY);

        int mouseXpx = (int) minecraft.mouseHandler.getScaledXPos(minecraft.getWindow());
        int mouseYpx = (int) minecraft.mouseHandler.getScaledYPos(minecraft.getWindow());
        float scaledW = (float) minecraft.getWindow().getGuiScaledWidth();
        float scaledH = (float) minecraft.getWindow().getGuiScaledHeight();
        // Store mouse as normalized offset from screen centre. When the menu first opens, force
        // the cursor to the centre (as in the normal game) so the trail doesn't start off-centre.
        boolean justOpened = !lastMenuOpen;
        float mouseX = justOpened ? 0.0f : (mouseXpx - scaledW / 2.0f) / scaledW;
        float mouseY = justOpened ? 0.0f : (mouseYpx - scaledH / 2.0f) / scaledH;

        ItemStack carried = menu.getCarried();
        ItemStack carriedCopy = carried == null || carried.isEmpty() ? ItemStack.EMPTY : carried.copy();

        MenuSnapshot snapshot = new MenuSnapshot(
                dimension, uuid, texture, title, width, height,
                true, mouseX, mouseY, carriedCopy, slots);

        // Written every tick while the menu is open so the mouse/carried trail is continuous.
        submitMenu(tickCounter, snapshot);
        lastMenuOpen = true;
    }

    /** Maps an open menu to the vanilla GUI texture used to draw it. */
    private static Identifier textureForMenu(AbstractContainerMenu menu) {
        if (menu instanceof CraftingMenu) return guiTexture("crafting_table");
        if (menu instanceof FurnaceMenu) return guiTexture("furnace");
        if (menu instanceof SmokerMenu) return guiTexture("smoker");
        if (menu instanceof BlastFurnaceMenu) return guiTexture("blast_furnace");
        if (menu instanceof BrewingStandMenu) return guiTexture("brewing_stand");
        if (menu instanceof EnchantmentMenu) return guiTexture("enchanting_table");
        if (menu instanceof AnvilMenu) return guiTexture("anvil");
        if (menu instanceof BeaconMenu) return guiTexture("beacon");
        if (menu instanceof GrindstoneMenu) return guiTexture("grindstone");
        if (menu instanceof CartographyTableMenu) return guiTexture("cartography_table");
        if (menu instanceof LoomMenu) return guiTexture("loom");
        if (menu instanceof SmithingMenu) return guiTexture("smithing");
        if (menu instanceof StonecutterMenu) return guiTexture("stonecutter");
        if (menu instanceof DispenserMenu) return guiTexture("dispenser");
        if (menu instanceof HopperMenu) return guiTexture("hopper");
        if (menu instanceof ShulkerBoxMenu) return guiTexture("shulker_box");
        if (menu instanceof HorseInventoryMenu) return guiTexture("horse");
        if (menu instanceof MerchantMenu) return guiTexture("villager");
        if (menu instanceof CrafterMenu) return guiTexture("crafter");
        if (menu instanceof ChestMenu chest) {
            int size = chest.getContainer().getContainerSize();
            return size <= 27 ? guiTexture("chest") : guiTexture("generic_54");
        }
        return null;
    }

    private static Identifier guiTexture(String name) {
        return Identifier.fromNamespaceAndPath("flashback_inventory", "textures/gui/container/" + name + ".png");
    }

    /** Extracts the container key ("chest") from a GUI texture id (".../gui/container/chest.png"), or null. */
    private static String textureKey(Identifier texture) {
        String path = texture.getPath();
        final String prefix = "textures/gui/container/";
        if (path.startsWith(prefix) && path.endsWith(".png")) {
            return path.substring(prefix.length(), path.length() - 4);
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Nearby containers
    // ------------------------------------------------------------------

    private static void captureContainers(Minecraft minecraft, ResourceKey<Level> dimension) {
        ClientLevel level = minecraft.level;
        LocalPlayer player = minecraft.player;
        BlockPos center = player.blockPosition();
        int radius = Math.max(8, FlashbackInventoryConfig.containerScanRadius);
        long radiusSquared = (long) radius * radius;
        int radiusChunks = (radius + 15) / 16;

        try {
            ChunkPos centerChunk = player.chunkPosition();
            for (int cz = centerChunk.z() - radiusChunks; cz <= centerChunk.z() + radiusChunks; cz++) {
                for (int cx = centerChunk.x() - radiusChunks; cx <= centerChunk.x() + radiusChunks; cx++) {
                    LevelChunk chunk = level.getChunk(cx, cz);
                    if (chunk == null) {
                        continue;
                    }
                    for (BlockPos pos : chunk.getBlockEntitiesPos()) {
                        BlockEntity blockEntity = level.getBlockEntity(pos);
                        if (!(blockEntity instanceof Container container)) {
                            continue;
                        }
                        if (center.distSqr(pos) > radiusSquared) {
                            continue;
                        }

                        Map<Integer, ItemStack> slots = new LinkedHashMap<>();
                        for (int i = 0; i < container.getContainerSize(); i++) {
                            ItemStack stack = container.getItem(i);
                            if (!stack.isEmpty()) slots.put(i, stack.copy());
                        }

                        int hash = hashOf(slots);
                        Integer previous = lastContainerHashes.get(pos);
                        if (previous == null || previous != hash) {
                            lastContainerHashes.put(pos, hash);
                            String title = blockEntity.getBlockState().getBlock().getName().getString();
                            submitContainer(tickCounter, InventorySnapshot.ofContainer(
                                    dimension, pos, title, container.getContainerSize(), slots));
                        }
                    }
                }
            }
        } catch (Throwable t) {
            // The scan is best-effort; a single failure should not break recording.
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private static int hashOf(Map<Integer, ItemStack> slots) {
        int hash = 1;
        for (Map.Entry<Integer, ItemStack> entry : slots.entrySet()) {
            hash = hash * 31 + entry.getKey();
            ItemStack stack = entry.getValue();
            hash = hash * 31 + stack.getCount();
            hash = hash * 31 + stack.getItem().hashCode();
        }
        return hash;
    }

    private static int hashOfSlots(List<MenuSnapshot.MenuSlotData> slots) {
        int hash = 1;
        for (MenuSnapshot.MenuSlotData s : slots) {
            hash = hash * 31 + s.x();
            hash = hash * 31 + s.y();
            hash = hash * 31 + s.stack().getCount();
            hash = hash * 31 + s.stack().getItem().hashCode();
        }
        return hash;
    }

    private static void submitPlayer(int tick, InventorySnapshot snapshot) {
        submit(writer -> {
            writer.startAction(ActionInventorySnapshot.INSTANCE);
            InventorySnapshot.STREAM_CODEC.encode(writer.friendlyByteBuf(), snapshot);
            writer.finishAction(ActionInventorySnapshot.INSTANCE);
        });
    }

    private static void submitContainer(int tick, InventorySnapshot snapshot) {
        submit(writer -> {
            writer.startAction(ActionInventorySnapshot.INSTANCE);
            InventorySnapshot.STREAM_CODEC.encode(writer.friendlyByteBuf(), snapshot);
            writer.finishAction(ActionInventorySnapshot.INSTANCE);
        });
    }

    private static void submitMenu(int tick, MenuSnapshot snapshot) {
        submit(writer -> {
            writer.startAction(ActionMenuSnapshot.INSTANCE);
            MenuSnapshot.STREAM_CODEC.encode(writer.friendlyByteBuf(), snapshot);
            writer.finishAction(ActionMenuSnapshot.INSTANCE);
        });
    }

    private static void submitScreen(int tick, ScreenSnapshot snapshot) {
        submit(writer -> {
            writer.startAction(ActionScreenSnapshot.INSTANCE);
            ScreenSnapshot.STREAM_CODEC.encode(writer.friendlyByteBuf(), snapshot);
            writer.finishAction(ActionScreenSnapshot.INSTANCE);
        });
    }

    private static void submit(java.util.function.Consumer<com.moulberry.flashback.io.ReplayWriter> task) {
        if (Flashback.RECORDER == null || !Flashback.RECORDER.readyToWrite()) {
            return;
        }
        Flashback.RECORDER.submitCustomTask(task);
    }
}
