package com.flashbackinventory.render;

import com.flashbackinventory.FlashbackInventory;
import com.flashbackinventory.config.FlashbackInventoryConfig;
import com.flashbackinventory.record.MenuSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.Flashback;
import com.moulberry.flashback.playback.ReplayServer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * Redraws the recorded GUI in the centre of the screen while spectating a player's
 * first-person view during a Flashback replay and that player has a menu open.
 * <p>
 * Uses a clean translucent style: the world is dimmed in the background, the panel and every
 * slot (including empty ones) are drawn as translucent wells, and the player's mouse trail and
 * the item held by the cursor during recording are also shown.
 */
public final class ReplayInventoryOverlay implements HudElement {

    public static final Identifier ID = FlashbackInventory.id("replay_inventory_overlay");

    /** Toggleable via the mod keybind. */
    public static volatile boolean enabled = true;

    /** Shared condition used by the overlay and the crosshair-hiding mixin. */
    public static boolean isGuiVisible() {
        if (!enabled || !FlashbackInventoryConfig.renderEnabled || !Flashback.isInReplay()) {
            return false;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return false;
        }
        if (!minecraft.options.getCameraType().isFirstPerson()) {
            return false;
        }
        if (!(minecraft.getCameraEntity() instanceof Player player)) {
            return false;
        }
        ReplayServer server = Flashback.getReplayServer();
        if (server == null) {
            return false;
        }
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), server.getReplayTick());
        return menu != null && menu.open();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor extractor, DeltaTracker deltaTracker) {
        if (!isGuiVisible()) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        Player player = (Player) minecraft.getCameraEntity();
        ReplayServer server = Flashback.getReplayServer();
        int tick = server.getReplayTick();
        MenuSnapshot menu = ReplayInventoryStore.getMenu(
                player.getUUID(), minecraft.level.dimension(), tick);
        if (menu == null) {
            return;
        }
        List<MenuSnapshot> recent = ReplayInventoryStore.getRecentMenus(
                player.getUUID(), minecraft.level.dimension(), tick, 30);
        drawMenu(extractor, minecraft, menu, recent);
    }

    private void drawMenu(GuiGraphicsExtractor extractor, Minecraft minecraft,
                          MenuSnapshot menu, List<MenuSnapshot> recent) {
        int width = menu.width();
        int height = menu.height();
        int x = (minecraft.getWindow().getGuiScaledWidth() - width) / 2;
        int y = (minecraft.getWindow().getGuiScaledHeight() - height) / 2;

        // Translucent world background.
        extractor.fill(0, 0, minecraft.getWindow().getGuiScaledWidth(),
                minecraft.getWindow().getGuiScaledHeight(), 0x55000000);
        // Lighter panel background.
        extractor.fill(x, y, x + width, y + height, 0x26000000);

        // Slot wells for ALL slots (empty slots render as wells too) + items.
        Font font = minecraft.font;
        for (MenuSnapshot.MenuSlotData s : menu.slots()) {
            int sx = x + s.x();
            int sy = y + s.y();
            extractor.fill(sx, sy, sx + 16, sy + 16, 0x40000000);
            ItemStack stack = s.stack();
            if (!stack.isEmpty()) {
                extractor.item(stack, sx + 1, sy + 1);
                extractor.itemDecorations(font, stack, sx + 1, sy + 1);
            }
        }

        // Menu title.
        if (menu.title() != null && !menu.title().isEmpty()) {
            extractor.text(font, menu.title(), x + 8, y + 6, 0xFFFFFFFF);
        }

        // Mouse trail: recent recorded cursor positions (normalized centre-relative -> screen).
        float sw = minecraft.getWindow().getGuiScaledWidth();
        float sh = minecraft.getWindow().getGuiScaledHeight();
        for (MenuSnapshot m : recent) {
            int rx = (int) (sw / 2.0f + m.mouseX() * sw);
            int ry = (int) (sh / 2.0f + m.mouseY() * sh);
            extractor.fill(rx, ry, rx + 3, ry + 3, 0x80FFFFFF);
        }
        // Current cursor marker.
        int mx = (int) (sw / 2.0f + menu.mouseX() * sw);
        int my = (int) (sh / 2.0f + menu.mouseY() * sh);
        extractor.fill(mx - 2, my - 2, mx + 2, my + 2, 0xFFFFFFFF);
        // Item held by the cursor.
        ItemStack carried = menu.carried();
        if (carried != null && !carried.isEmpty()) {
            extractor.item(carried, mx - 8, my - 8);
        }
    }
}
