package com.flashbackinventory;

import com.flashbackinventory.gui.FlashbackInventoryConfigScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Mod Menu integration: exposes the config screen for flashback-inventory.
 */
public final class FlashbackInventoryModMenu implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return FlashbackInventoryConfigScreen::new;
    }
}
