package com.flashbackinventory.action;

import com.flashbackinventory.record.InventorySnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.action.Action;
import com.moulberry.flashback.playback.ReplayServer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.Identifier;

/**
 * Custom Flashback {@link Action} that carries an {@link InventorySnapshot}.
 * <p>
 * While recording, snapshots are written into the .flashback file with this action id.
 * While playing back, Flashback's ReplayServer applies them by calling {@link #handle},
 * which updates the shared {@link ReplayInventoryStore} that the overlay reads from.
 */
public final class ActionInventorySnapshot implements Action {

    private static final Identifier NAME = Identifier.fromNamespaceAndPath(
            "flashback_inventory", "inventory_snapshot");

    public static final ActionInventorySnapshot INSTANCE = new ActionInventorySnapshot();

    private ActionInventorySnapshot() {
    }

    @Override
    public Identifier name() {
        return NAME;
    }

    @Override
    public void handle(ReplayServer replayServer, RegistryFriendlyByteBuf friendlyByteBuf) {
        InventorySnapshot snapshot = InventorySnapshot.STREAM_CODEC.decode(friendlyByteBuf);
        int tick = replayServer.getReplayTick();
        if (snapshot.target() == InventorySnapshot.Target.PLAYER) {
            ReplayInventoryStore.putPlayer(tick, snapshot);
        } else {
            ReplayInventoryStore.putContainer(tick, snapshot);
        }
    }
}
