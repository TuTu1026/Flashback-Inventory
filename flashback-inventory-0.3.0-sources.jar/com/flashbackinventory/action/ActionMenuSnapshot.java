package com.flashbackinventory.action;

import com.flashbackinventory.record.MenuSnapshot;
import com.flashbackinventory.store.ReplayInventoryStore;
import com.moulberry.flashback.action.Action;
import com.moulberry.flashback.playback.ReplayServer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.Identifier;

/**
 * Custom Flashback {@link Action} carrying a {@link MenuSnapshot}.
 * <p>
 * Written into the .flashback file while recording; applied by the ReplayServer during playback,
 * storing the menu snapshot keyed by the current replay tick.
 */
public final class ActionMenuSnapshot implements Action {

    private static final Identifier NAME = Identifier.fromNamespaceAndPath(
            "flashback_inventory", "menu_snapshot");

    public static final ActionMenuSnapshot INSTANCE = new ActionMenuSnapshot();

    private ActionMenuSnapshot() {
    }

    @Override
    public Identifier name() {
        return NAME;
    }

    @Override
    public void handle(ReplayServer replayServer, RegistryFriendlyByteBuf buf) {
        MenuSnapshot snapshot = MenuSnapshot.STREAM_CODEC.decode(buf);
        ReplayInventoryStore.putMenu(replayServer.getReplayTick(), snapshot);
    }
}
