package com.flashbackinventory.mixin;

import com.flashbackinventory.render.ReplayInventoryOverlay;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hides the crosshair while the replay GUI overlay is being drawn, so the redrawn
 * interface (which sits in the centre of the screen) isn't cluttered by the crosshair.
 */
@Mixin(Hud.class)
public abstract class HudMixin {

    @Inject(method = "extractCrosshair", at = @At("HEAD"), cancellable = true)
    private void flashbackInventory_hideCrosshair(
            GuiGraphicsExtractor extractor, DeltaTracker deltaTracker, CallbackInfo ci) {
        if (ReplayInventoryOverlay.isGuiVisible()) {
            ci.cancel();
        }
    }
}
