package com.flashbackinventory.texture;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Loads the mod's GUI textures (packed PNGs) into a {@link DynamicTexture} and registers them
 * with the {@code TextureManager}, so {@code GuiGraphicsExtractor.blit(Identifier, ...)} can
 * resolve a valid GPU texture view. Called lazily from the render thread before blitting.
 */
public final class GuiTextureCache {

    private static final Map<Identifier, Identifier> LOADED = new HashMap<>();

    private GuiTextureCache() {
    }

    /** Ensures the given GUI texture is loaded and registered; safe to call every frame. */
    public static void ensureLoaded(Identifier textureId) {
        if (textureId == null || LOADED.containsKey(textureId)) {
            return;
        }
        try {
            Minecraft minecraft = Minecraft.getInstance();
            ResourceManager rm = minecraft.getResourceManager();
            List<Resource> stack = rm.getResourceStack(textureId);
            if (stack.isEmpty()) {
                return;
            }
            NativeImage image = NativeImage.read(stack.get(0).open());
            DynamicTexture texture = new DynamicTexture(() -> textureId.toString(), image);
            minecraft.getTextureManager().register(textureId, texture);
            LOADED.put(textureId, textureId);
        } catch (Throwable t) {
            // Best-effort; falls back to the translucent panel if the texture cannot be loaded.
        }
    }
}
