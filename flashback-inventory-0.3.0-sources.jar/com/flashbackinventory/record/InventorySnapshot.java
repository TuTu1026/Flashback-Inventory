package com.flashbackinventory.record;

import com.flashbackinventory.FlashbackInventory;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * A serialisable snapshot of either a player's full inventory or a container's contents.
 * <p>
 * It doubles as a {@link CustomPacketPayload} so that it can be carried both inside a replay
 * Action (persisted in the .flashback file) and inside a normal custom payload sent to replay
 * viewers while playing back.
 */
public record InventorySnapshot(
        Target target,
        ResourceKey<Level> dimension,
        UUID playerUuid,
        BlockPos blockPos,
        String title,
        int containerSize,
        Map<Integer, ItemStack> slots
) implements CustomPacketPayload {

    public enum Target { PLAYER, CONTAINER }

    public static final Type<InventorySnapshot> TYPE =
            new Type<>(FlashbackInventory.id("inventory_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, InventorySnapshot> STREAM_CODEC =
            new InventorySnapshotStreamCodec();

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    /** Builds a full player inventory snapshot (all 41 slots, empty slots omitted). */
    public static InventorySnapshot ofPlayer(ResourceKey<Level> dimension, UUID uuid, Map<Integer, ItemStack> slots) {
        return new InventorySnapshot(Target.PLAYER, dimension, uuid, null, "Player Inventory", 41, slots);
    }

    /** Builds a container snapshot keyed by its block position. */
    public static InventorySnapshot ofContainer(ResourceKey<Level> dimension, BlockPos pos,
                                                String title, int containerSize,
                                                Map<Integer, ItemStack> slots) {
        return new InventorySnapshot(Target.CONTAINER, dimension, null, pos, title, containerSize, slots);
    }

    private static final class InventorySnapshotStreamCodec
            implements StreamCodec<RegistryFriendlyByteBuf, InventorySnapshot> {

        @Override
        public InventorySnapshot decode(RegistryFriendlyByteBuf buf) {
            Target target = buf.readEnum(Target.class);
            ResourceKey<Level> dimension = buf.readResourceKey(Registries.DIMENSION);
            UUID playerUuid = buf.readBoolean() ? buf.readUUID() : null;
            BlockPos blockPos = buf.readBoolean() ? buf.readBlockPos() : null;
            String title = buf.readUtf();
            int containerSize = buf.readVarInt();

            Map<Integer, ItemStack> slots = new LinkedHashMap<>();
            int count = buf.readVarInt();
            for (int i = 0; i < count; i++) {
                int slot = buf.readVarInt();
                ItemStack stack = ItemStack.OPTIONAL_STREAM_CODEC.decode(buf);
                slots.put(slot, stack);
            }
            return new InventorySnapshot(target, dimension, playerUuid, blockPos, title, containerSize, slots);
        }

        @Override
        public void encode(RegistryFriendlyByteBuf buf, InventorySnapshot snapshot) {
            buf.writeEnum(snapshot.target());
            buf.writeResourceKey(snapshot.dimension());
            buf.writeBoolean(snapshot.playerUuid() != null);
            if (snapshot.playerUuid() != null) {
                buf.writeUUID(snapshot.playerUuid());
            }
            buf.writeBoolean(snapshot.blockPos() != null);
            if (snapshot.blockPos() != null) {
                buf.writeBlockPos(snapshot.blockPos());
            }
            buf.writeUtf(snapshot.title());
            buf.writeVarInt(snapshot.containerSize());

            buf.writeVarInt(snapshot.slots().size());
            for (Map.Entry<Integer, ItemStack> entry : snapshot.slots().entrySet()) {
                buf.writeVarInt(entry.getKey());
                ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, entry.getValue());
            }
        }
    }
}
