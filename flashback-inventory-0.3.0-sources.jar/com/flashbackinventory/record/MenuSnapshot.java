package com.flashbackinventory.record;

import com.flashbackinventory.FlashbackInventory;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * A serialisable snapshot of a container/inventory {@code Menu} as it was open while recording.
 * <p>
 * Records the GUI texture, window size and every slot's on-screen position + item, so the
 * replay overlay can faithfully redraw the exact interface (including crafting-table recipes).
 * Also carried as a {@link CustomPacketPayload} for replay viewers.
 */
public record MenuSnapshot(
        ResourceKey<Level> dimension,
        UUID playerUuid,
        Identifier textureId,
        String title,
        int width,
        int height,
        boolean open,
        float mouseX,
        float mouseY,
        ItemStack carried,
        List<MenuSlotData> slots
) implements CustomPacketPayload {

    /** A single slot: on-screen x/y (relative to the GUI panel) plus its item. */
    public record MenuSlotData(int x, int y, ItemStack stack) {
    }

    public static final Type<MenuSnapshot> TYPE =
            new Type<>(FlashbackInventory.id("menu_snapshot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MenuSnapshot> STREAM_CODEC =
            new MenuSnapshotStreamCodec();

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    private static final class MenuSnapshotStreamCodec
            implements StreamCodec<RegistryFriendlyByteBuf, MenuSnapshot> {

        @Override
        public MenuSnapshot decode(RegistryFriendlyByteBuf buf) {
            ResourceKey<Level> dimension = buf.readResourceKey(Registries.DIMENSION);
            UUID playerUuid = buf.readUUID();
            Identifier textureId = Identifier.STREAM_CODEC.decode(buf);
            String title = buf.readUtf();
            int width = buf.readVarInt();
            int height = buf.readVarInt();
            boolean open = buf.readBoolean();
            float mouseX = buf.readFloat();
            float mouseY = buf.readFloat();
            ItemStack carried = ItemStack.OPTIONAL_STREAM_CODEC.decode(buf);
            int count = buf.readVarInt();
            List<MenuSlotData> slots = new ArrayList<>(count);
            for (int i = 0; i < count; i++) {
                int x = buf.readVarInt();
                int y = buf.readVarInt();
                ItemStack stack = ItemStack.OPTIONAL_STREAM_CODEC.decode(buf);
                slots.add(new MenuSlotData(x, y, stack));
            }
            return new MenuSnapshot(dimension, playerUuid, textureId, title,
                    width, height, open, mouseX, mouseY, carried, slots);
        }

        @Override
        public void encode(RegistryFriendlyByteBuf buf, MenuSnapshot snap) {
            buf.writeResourceKey(snap.dimension());
            buf.writeUUID(snap.playerUuid());
            Identifier.STREAM_CODEC.encode(buf, snap.textureId());
            buf.writeUtf(snap.title());
            buf.writeVarInt(snap.width());
            buf.writeVarInt(snap.height());
            buf.writeBoolean(snap.open());
            buf.writeFloat(snap.mouseX());
            buf.writeFloat(snap.mouseY());
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, snap.carried());
            buf.writeVarInt(snap.slots().size());
            for (MenuSlotData s : snap.slots()) {
                buf.writeVarInt(s.x());
                buf.writeVarInt(s.y());
                ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, s.stack());
            }
        }
    }
}
