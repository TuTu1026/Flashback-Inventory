package com.flashbackinventory.gui;

import com.flashbackinventory.config.FlashbackInventoryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration screen opened from Mod Menu. Supports switching between English and 中文,
 * selecting all/none container GUI types, per-container recording toggles, and mouse-trail options.
 */
public final class FlashbackInventoryConfigScreen extends Screen {

    private static final Map<String, String> ZH_NAMES = new HashMap<>();

    static {
        ZH_NAMES.put("inventory", "物品栏");
        ZH_NAMES.put("chest", "箱子");
        ZH_NAMES.put("crafting_table", "工作台");
        ZH_NAMES.put("furnace", "熔炉");
        ZH_NAMES.put("smoker", "烟熏炉");
        ZH_NAMES.put("blast_furnace", "高炉");
        ZH_NAMES.put("brewing_stand", "酿造台");
        ZH_NAMES.put("enchanting_table", "附魔台");
        ZH_NAMES.put("anvil", "铁砧");
        ZH_NAMES.put("beacon", "信标");
        ZH_NAMES.put("grindstone", "磨石");
        ZH_NAMES.put("cartography_table", "制图台");
        ZH_NAMES.put("loom", "织布机");
        ZH_NAMES.put("smithing", "锻造台");
        ZH_NAMES.put("stonecutter", "切石机");
        ZH_NAMES.put("dispenser", "发射器");
        ZH_NAMES.put("hopper", "漏斗");
        ZH_NAMES.put("shulker_box", "潜影盒");
        ZH_NAMES.put("horse", "马");
        ZH_NAMES.put("villager", "村民");
        ZH_NAMES.put("crafter", "合成器");
    }

    private final Screen parent;

    public FlashbackInventoryConfigScreen(Screen parent) {
        super(Component.literal(t("Flashback Inventory Settings", "Flashback 背包设置")));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        // 1) Language toggle - always first.
        Button langBtn = Button.builder(
                Component.literal(t("Language: English", "语言：中文")), b -> {
                    FlashbackInventoryConfig.language = FlashbackInventoryConfig.language.equals("zh") ? "en" : "zh";
                    FlashbackInventoryConfig.save();
                    Minecraft.getInstance().gui.setScreen(new FlashbackInventoryConfigScreen(parent));
                }).bounds(cx - 150, 8, 300, 18).build();
        this.addRenderableWidget(langBtn);

        // 2) Master render toggle.
        Button renderBtn = Button.builder(
                Component.literal(t("Render replay GUI: " + onoff(FlashbackInventoryConfig.renderEnabled),
                        "回放渲染GUI：" + onoff(FlashbackInventoryConfig.renderEnabled))), b -> {
                    FlashbackInventoryConfig.renderEnabled = !FlashbackInventoryConfig.renderEnabled;
                    FlashbackInventoryConfig.save();
                    b.setMessage(Component.literal(t("Render replay GUI: " + onoff(FlashbackInventoryConfig.renderEnabled),
                            "回放渲染GUI：" + onoff(FlashbackInventoryConfig.renderEnabled))));
                }).bounds(cx - 150, 30, 300, 18).build();
        this.addRenderableWidget(renderBtn);

        // 3) Mouse-trail recording toggle.
        Button trailBtn = Button.builder(
                Component.literal(t("Record mouse trail: " + onoff(FlashbackInventoryConfig.recordMouseTrail),
                        "录制鼠标轨迹：" + onoff(FlashbackInventoryConfig.recordMouseTrail))), b -> {
                    FlashbackInventoryConfig.recordMouseTrail = !FlashbackInventoryConfig.recordMouseTrail;
                    FlashbackInventoryConfig.save();
                    b.setMessage(Component.literal(t("Record mouse trail: " + onoff(FlashbackInventoryConfig.recordMouseTrail),
                            "录制鼠标轨迹：" + onoff(FlashbackInventoryConfig.recordMouseTrail))));
                }).bounds(cx - 150, 52, 300, 18).build();
        this.addRenderableWidget(trailBtn);

        // 4) Trail tail length.
        Button trailLenBtn = Button.builder(
                Component.literal(t("Trail tail length: " + FlashbackInventoryConfig.trailLength,
                        "轨迹尾巴长度：" + FlashbackInventoryConfig.trailLength)), b -> {
                    int len = FlashbackInventoryConfig.trailLength + 10;
                    if (len > 60) {
                        len = 10;
                    }
                    FlashbackInventoryConfig.trailLength = len;
                    FlashbackInventoryConfig.save();
                    b.setMessage(Component.literal(t("Trail tail length: " + FlashbackInventoryConfig.trailLength,
                            "轨迹尾巴长度：" + FlashbackInventoryConfig.trailLength)));
                }).bounds(cx - 150, 74, 300, 18).build();
        this.addRenderableWidget(trailLenBtn);

        // 5) Select all / none.
        Button allBtn = Button.builder(Component.literal(t("Select all", "全选")), b -> {
            for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
                FlashbackInventoryConfig.containerEnabled.put(key, true);
            }
            FlashbackInventoryConfig.save();
            rebuildButtons();
        }).bounds(cx - 150, 96, 145, 18).build();
        this.addRenderableWidget(allBtn);
        Button noneBtn = Button.builder(Component.literal(t("Select none", "全不选")), b -> {
            for (String key : FlashbackInventoryConfig.CONTAINER_KEYS) {
                FlashbackInventoryConfig.containerEnabled.put(key, false);
            }
            FlashbackInventoryConfig.save();
            rebuildButtons();
        }).bounds(cx + 5, 96, 145, 18).build();
        this.addRenderableWidget(noneBtn);

        // 6) Per-container toggles, 3 per row.
        int cols = 3;
        int rowH = 18;
        int startY = 118;
        int btnW = 98;
        int gap = 4;
        for (int i = 0; i < FlashbackInventoryConfig.CONTAINER_KEYS.size(); i++) {
            String key = FlashbackInventoryConfig.CONTAINER_KEYS.get(i);
            int col = i % cols;
            int row = i / cols;
            int bx = cx - 150 + col * (btnW + gap);
            int by = startY + row * rowH;
            Button cb = Button.builder(Component.literal(containerLabel(key)), b -> {
                boolean v = FlashbackInventoryConfig.containerEnabled.getOrDefault(key, true);
                FlashbackInventoryConfig.containerEnabled.put(key, !v);
                FlashbackInventoryConfig.save();
                b.setMessage(Component.literal(containerLabel(key)));
            }).bounds(bx, by, btnW, 16).build();
            this.addRenderableWidget(cb);
        }

        // 7) Done.
        Button done = Button.builder(Component.literal(t("Done", "完成")), b -> this.onClose())
                .bounds(cx - 100, this.height - 30, 200, 20).build();
        this.addRenderableWidget(done);
    }

    private void rebuildButtons() {
        Minecraft.getInstance().gui.setScreen(new FlashbackInventoryConfigScreen(parent));
    }

    private static String containerLabel(String key) {
        String name = FlashbackInventoryConfig.language.equals("zh")
                ? ZH_NAMES.getOrDefault(key, key)
                : key;
        boolean on = FlashbackInventoryConfig.containerEnabled.getOrDefault(key, true);
        return name + ":" + onoff(on);
    }

    private static String onoff(boolean on) {
        return on ? (FlashbackInventoryConfig.language.equals("zh") ? "开" : "ON")
                : (FlashbackInventoryConfig.language.equals("zh") ? "关" : "OFF");
    }

    private static String t(String en, String zh) {
        return FlashbackInventoryConfig.language.equals("zh") ? zh : en;
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().gui.setScreen(parent);
    }
}
